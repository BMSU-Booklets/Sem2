import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { ResourceList } from '../components/ResourceList';
import { Alert, Crumbs, Empty, Field, Spinner, useToast } from '../components/ui';
import { getCourse, listBookmarks, listCategories, listCourses, listResources, setBookmark, updateMyName } from '../lib/content-api';
import { friendlyError, toFaDigits } from '../lib/fa';
import type { Category, Course, Resource } from '../lib/types';

function useBookmarks() {
  const { session } = useAuth(), toast = useToast();
  const [set, setSet] = useState<Set<string>>(new Set());
  useEffect(() => { listBookmarks().then((l) => setSet(new Set(l))).catch(() => {}); }, []);
  const toggle = useCallback(async (id: string, on: boolean) => {
    try { await setBookmark(session!.user.id, id, on); setSet((s) => { const n = new Set(s); on ? n.add(id) : n.delete(id); return n; }); }
    catch (e) { toast(friendlyError(e), true); }
  }, [session, toast]);
  return [set, toggle] as const;
}

export function Home() {
  const a = useAuth();
  const [courses, setCourses] = useState<Course[] | null>(null), [resources, setResources] = useState<Resource[]>([]), [err, setErr] = useState<string | null>(null);
  const [bm, toggle] = useBookmarks();
  const [searching, setSearching] = useState('');
  useEffect(() => { Promise.all([listCourses(), listResources()]).then(([c, r]) => { setCourses(c); setResources(r); }).catch((e) => setErr(friendlyError(e))); }, []);
  const counts = useMemo(() => { const m = new Map<string, number>(); resources.forEach((r) => m.set(r.course_id, (m.get(r.course_id) ?? 0) + 1)); return m; }, [resources]);
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!courses) return <Spinner />;
  return <>
    <div className="hero"><div className="logo" aria-hidden style={{ overflow: 'hidden' }}>{a.settings?.logo_url ? <img src={a.settings.logo_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '📚'}</div><h1>{a.settings?.site_title}</h1></div>
    <p className="subtitle">{a.settings?.site_subtitle}</p>
    <div className="toolbar"><input className="input" type="search" aria-label="جستجو در همهٔ منابع" placeholder="جستجو در همهٔ منابع…" value={searching} onChange={(e) => setSearching(e.target.value)} /></div>
    {searching.trim() ? <ResourceList items={resources} courses={courses} bookmarked={bm} onToggleBookmark={toggle} /> :
      courses.length === 0 ? <Empty icon="📚" title="هنوز درسی اضافه نشده است">پس از افزودن درس توسط مدیر، اینجا نمایش داده می‌شود.</Empty> :
      courses.map((c, i) => <Link key={c.id} to={`/course/${c.id}`} className="card course-card" aria-label={c.title}>
        <span className={`icon-circle alt${i % 5}`} aria-hidden>{c.image_url ? <img src={c.image_url} alt="" loading="lazy" /> : c.icon}</span>
        <div className="body"><h2 style={{ margin: 0 }}>{c.title}</h2><p>{c.description}</p>
          <div className="meta"><span className="badge">{toFaDigits(counts.get(c.id) ?? 0)} منبع</span>{c.restricted && <span className="badge warn">دسترسی ویژه</span>}</div></div>
        <span className="arrow" aria-hidden>‹</span></Link>)}
  </>;
}

export function CoursePage() {
  const { courseId = '', categoryId } = useParams();
  const a = useAuth();
  const [course, setCourse] = useState<Course | null>(null), [cats, setCats] = useState<Category[]>([]), [items, setItems] = useState<Resource[] | null>(null), [err, setErr] = useState<string | null>(null);
  const [bm, toggle] = useBookmarks();
  useEffect(() => {
    setItems(null); setErr(null);
    Promise.all([getCourse(courseId), listCategories(courseId), listResources({ courseId, includeDrafts: a.can('resources.edit') })])
      .then(([c, g, r]) => { setCourse(c); setCats(g); setItems(r); })
      .catch((e) => setErr(friendlyError(e)));
  }, [courseId, a]);
  if (err) return <Alert kind="error">{err} <Link to="/library">بازگشت</Link></Alert>;
  if (!course || !items) return <Spinner />;
  const current = cats.find((c) => c.id === categoryId);
  const top = cats.filter((c) => !c.parent_id), children = current ? cats.filter((c) => c.parent_id === current.id) : [];
  const ids = new Set(current ? [current.id, ...children.map((c) => c.id)] : []);
  const visible = current ? items.filter((r) => r.category_id && ids.has(r.category_id)) : items;
  return <>
    <Crumbs items={[{ to: '/library', label: 'کتابخانه' }, current ? { to: `/course/${course.id}`, label: course.title } : { label: course.title }, ...(current ? [{ label: current.title }] : [])]} />
    <div className="hero" style={{ justifyContent: 'flex-start' }}><span className="icon-circle" aria-hidden>{course.image_url ? <img src={course.image_url} alt="" /> : course.icon}</span><div style={{ textAlign: 'right' }}><h1 style={{ margin: 0 }}>{current ? current.title : course.title}</h1><p style={{ margin: 0 }}>{course.description}</p></div></div>
    {top.length > 0 && <div className="chips" role="group" aria-label="دسته‌بندی‌ها" style={{ marginTop: 16 }}>
      <Link className="chip" aria-pressed={!current} to={`/course/${course.id}`}>همه</Link>
      {top.map((c) => <Link key={c.id} className="chip" aria-pressed={current?.id === c.id || current?.parent_id === c.id} to={`/course/${course.id}/category/${c.id}`}>{c.title}</Link>)}
    </div>}
    {children.length > 0 && <div className="chips">{children.map((c) => <Link key={c.id} className="chip" to={`/course/${course.id}/category/${c.id}`}>{c.title}</Link>)}</div>}
    <ResourceList items={visible} categories={cats} bookmarked={bm} onToggleBookmark={toggle} showDrafts={a.can('resources.edit')} />
  </>;
}

export function Bookmarks() {
  const [items, setItems] = useState<Resource[] | null>(null), [courses, setCourses] = useState<Course[]>([]);
  const [bm, toggle] = useBookmarks();
  useEffect(() => { Promise.all([listBookmarks(), listResources(), listCourses()]).then(([ids, all, c]) => { const s = new Set(ids); setItems(all.filter((r) => s.has(r.id))); setCourses(c); }).catch(() => setItems([])); }, []);
  if (!items) return <Spinner />;
  return <><Crumbs items={[{ to: '/library', label: 'کتابخانه' }, { label: 'نشان‌شده‌ها' }]} /><h1>نشان‌شده‌ها</h1>
    <ResourceList items={items} courses={courses} bookmarked={bm} onToggleBookmark={async (id, on) => { await toggle(id, on); if (!on) setItems((l) => l!.filter((r) => r.id !== id)); }} /></>;
}

export function Profile() {
  const a = useAuth(), toast = useToast();
  const [name, setName] = useState(a.profile?.full_name ?? ''), [busy, setBusy] = useState(false);
  const roleLabel = a.role === 'owner' ? 'مدیر اصلی' : a.role === 'content_manager' ? 'مدیر محتوا' : 'دانشجو';
  async function save() {
    if (name.trim().length < 3) return toast('نام را کامل وارد کنید.', true);
    setBusy(true);
    try { await updateMyName(a.session!.user.id, name); await a.refresh(); toast('ذخیره شد.'); } catch (e) { toast(friendlyError(e), true); } finally { setBusy(false); }
  }
  return <div className="card center-card"><h2>پروفایل</h2>
    <Field id="pn" label="نام و نام خانوادگی"><input id="pn" className="input" value={name} onChange={(e) => setName(e.target.value)} /></Field>
    <Field id="pe" label="ایمیل"><input id="pe" className="input" dir="ltr" value={a.profile?.email ?? ''} readOnly /></Field>
    <p>نقش: <span className="badge">{roleLabel}</span></p>
    <button className="btn primary" onClick={save} disabled={busy}>ذخیرهٔ تغییرات</button></div>;
}
