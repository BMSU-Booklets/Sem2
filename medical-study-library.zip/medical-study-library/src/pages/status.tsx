import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { signOut } from '../lib/auth-api';

function StatusCard({ icon, title, children, expect }: { icon: string; title: string; children: React.ReactNode; expect: string }) {
  const a = useAuth();
  if (!a.loading && a.profile?.status === 'active') return <Navigate to="/library" replace />;
  return <div className="card center-card empty"><div className="big" aria-hidden>{icon}</div><h2>{title}</h2><p>{children}</p>
    <div className="row" style={{ justifyContent: 'center' }}><button className="btn" onClick={() => void a.refresh()}>بررسی دوبارهٔ وضعیت</button><button className="btn" onClick={() => void signOut()}>خروج</button></div>
    <span hidden>{expect}</span></div>;
}
export const Pending = () => <StatusCard icon="⏳" title="در انتظار تأیید مدیر" expect="pending">ایمیل شما تأیید شده است. دسترسی به منابع پس از تأیید مدیر فعال می‌شود.</StatusCard>;
export const Rejected = () => <StatusCard icon="🚫" title="درخواست شما پذیرفته نشد" expect="rejected">مدیر درخواست دسترسی شما را نپذیرفته است. برای پیگیری با مدیر کتابخانه تماس بگیرید.</StatusCard>;
export const Suspended = () => <StatusCard icon="⛔" title="حساب شما معلق است" expect="suspended">دسترسی شما به منابع موقتاً متوقف شده است. برای اطلاعات بیشتر با مدیر کتابخانه تماس بگیرید.</StatusCard>;
export const Unauthorized = () => <div className="card center-card empty"><div className="big" aria-hidden>🔒</div><h2>دسترسی ندارید</h2><p>برای دیدن این صفحه مجوز لازم را ندارید.</p><Link className="btn" to="/library">بازگشت به کتابخانه</Link></div>;
export const NotFound = () => <div className="card center-card empty"><div className="big" aria-hidden>🧭</div><h2>صفحه پیدا نشد</h2><p>نشانی واردشده وجود ندارد.</p><Link className="btn" to="/">بازگشت به خانه</Link></div>;
