import { useState, type FormEvent } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { Alert, Field, Spinner } from '../components/ui';
import { requestPasswordReset, resendVerification, signIn, signUp, updatePassword } from '../lib/auth-api';
import { friendlyError, validateLogin, validateRegister, type FieldErrors } from '../lib/fa';
import { isConfigured } from '../lib/supabase';

export function Landing() {
  const a = useAuth();
  if (a.loading) return <Spinner full />;
  if (a.session && a.emailVerified) return <Navigate to="/library" replace />;
  return <>
    <div className="hero"><div className="logo" aria-hidden>{a.settings?.logo_url ? <img src={a.settings.logo_url} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%' }} /> : '📚'}</div><h1>{a.settings?.site_title}</h1></div>
    <p className="subtitle">{a.settings?.site_subtitle}</p>
    {!isConfigured && <Alert kind="error">اتصال به Supabase تنظیم نشده است. فایل <span className="ltr">.env.local</span> را طبق راهنما بسازید.</Alert>}
    <div className="card center-card" style={{ marginTop: 0 }}>
      <h2>ورود به کتابخانه</h2>
      <p>این کتابخانه خصوصی است. پس از ثبت‌نام و تأیید ایمیل، حساب شما توسط مدیر بررسی می‌شود و پس از تأیید می‌توانید منابع را ببینید.</p>
      <div className="row"><Link className="btn primary" to="/login">ورود</Link><Link className="btn" to="/register">ثبت‌نام</Link></div>
    </div>
  </>;
}

export function Register() {
  const [v, setV] = useState({ fullName: '', email: '', password: '', confirm: '' });
  const [errs, setErrs] = useState<FieldErrors>({});
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState<string | null>(null), [done, setDone] = useState(false);
  const a = useAuth();
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  async function submit(e: FormEvent) {
    e.preventDefault(); setMsg(null);
    const er = validateRegister(v); setErrs(er); if (Object.keys(er).length) return;
    setBusy(true);
    try { await signUp(v.fullName, v.email, v.password); setDone(true); } catch (x) { setMsg(friendlyError(x)); } finally { setBusy(false); }
  }
  if (done) return <div className="card center-card"><h2>ایمیل تأیید ارسال شد</h2><p>پیوند ارسال‌شده به <b className="ltr">{v.email}</b> را باز کنید. پس از تأیید ایمیل، درخواست شما برای بررسی به مدیر می‌رسد.</p><Link className="btn" to="/login">رفتن به صفحهٔ ورود</Link></div>;
  if (a.settings && !a.settings.registration_open) return <div className="card center-card"><h2>ثبت‌نام بسته است</h2><p>در حال حاضر ثبت‌نام کاربر جدید پذیرفته نمی‌شود.</p></div>;
  return <form className="card center-card" onSubmit={submit} noValidate>
    <h2>ثبت‌نام</h2>
    {msg && <Alert kind="error">{msg}</Alert>}
    <Field id="rn" label="نام و نام خانوادگی" error={errs.fullName}><input id="rn" className="input" value={v.fullName} onChange={set('fullName')} autoComplete="name" aria-invalid={!!errs.fullName} /></Field>
    <Field id="re" label="ایمیل" error={errs.email}><input id="re" className="input" dir="ltr" type="email" value={v.email} onChange={set('email')} autoComplete="email" aria-invalid={!!errs.email} /></Field>
    <Field id="rp" label="گذرواژه" error={errs.password} hint="دست‌کم ۸ نویسه، شامل حروف و عدد"><input id="rp" className="input" dir="ltr" type="password" value={v.password} onChange={set('password')} autoComplete="new-password" aria-invalid={!!errs.password} /></Field>
    <Field id="rc" label="تکرار گذرواژه" error={errs.confirm}><input id="rc" className="input" dir="ltr" type="password" value={v.confirm} onChange={set('confirm')} autoComplete="new-password" aria-invalid={!!errs.confirm} /></Field>
    <button className="btn primary" disabled={busy}>{busy ? 'در حال ارسال…' : 'ثبت‌نام'}</button>
    <p className="hint">حساب دارید؟ <Link to="/login">وارد شوید</Link></p>
  </form>;
}

export function Login() {
  const [v, setV] = useState({ email: '', password: '' }), [errs, setErrs] = useState<FieldErrors>({});
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState<string | null>(null), [unverified, setUnverified] = useState(false);
  const nav = useNavigate(), loc = useLocation();
  const from = (loc.state as { from?: string } | null)?.from ?? '/library';
  async function submit(e: FormEvent) {
    e.preventDefault(); setMsg(null); setUnverified(false);
    const er = validateLogin(v); setErrs(er); if (Object.keys(er).length) return;
    setBusy(true);
    try { await signIn(v.email, v.password); nav(from, { replace: true }); }
    catch (x) { setMsg(friendlyError(x)); setUnverified(String((x as Error).message).toLowerCase().includes('not confirmed')); }
    finally { setBusy(false); }
  }
  return <form className="card center-card" onSubmit={submit} noValidate>
    <h2>ورود</h2>
    {msg && <Alert kind="error">{msg}</Alert>}
    {unverified && <button type="button" className="btn small" onClick={async () => { try { await resendVerification(v.email); setMsg('ایمیل تأیید دوباره ارسال شد.'); } catch (x) { setMsg(friendlyError(x)); } }}>ارسال مجدد ایمیل تأیید</button>}
    <Field id="le" label="ایمیل" error={errs.email}><input id="le" className="input" dir="ltr" type="email" value={v.email} onChange={(e) => setV({ ...v, email: e.target.value })} autoComplete="email" aria-invalid={!!errs.email} /></Field>
    <Field id="lp" label="گذرواژه" error={errs.password}><input id="lp" className="input" dir="ltr" type="password" value={v.password} onChange={(e) => setV({ ...v, password: e.target.value })} autoComplete="current-password" aria-invalid={!!errs.password} /></Field>
    <button className="btn primary" disabled={busy}>{busy ? 'در حال ورود…' : 'ورود'}</button>
    <p className="hint"><Link to="/forgot-password">گذرواژه را فراموش کرده‌اید؟</Link> · <Link to="/register">ثبت‌نام</Link></p>
  </form>;
}

export function VerifyNotice() {
  const a = useAuth(); const [msg, setMsg] = useState<string | null>(null);
  if (a.loading) return <Spinner full />;
  if (a.emailVerified) return <Navigate to="/library" replace />;
  return <div className="card center-card"><h2>ایمیل خود را تأیید کنید</h2>
    <p>برای ادامه، پیوند تأیید ارسال‌شده به ایمیل خود را باز کنید.</p>
    {msg && <Alert kind="success">{msg}</Alert>}
    {a.session?.user.email && <button className="btn" onClick={async () => { try { await resendVerification(a.session!.user.email!); setMsg('ایمیل تأیید دوباره ارسال شد.'); } catch (x) { setMsg(friendlyError(x)); } }}>ارسال مجدد ایمیل</button>}</div>;
}
export const Verified = () => <div className="card center-card"><h2>ایمیل شما تأیید شد</h2><p>حساب شما اکنون در انتظار تأیید مدیر است. پس از تأیید می‌توانید وارد شوید.</p><Link className="btn primary" to="/login">ورود</Link></div>;

export function ForgotPassword() {
  const [email, setEmail] = useState(''), [msg, setMsg] = useState<string | null>(null), [err, setErr] = useState<string | null>(null), [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(null); setMsg(null);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) return setErr('نشانی ایمیل معتبر نیست.');
    setBusy(true);
    try { await requestPasswordReset(email); setMsg('اگر این ایمیل ثبت شده باشد، پیوند بازیابی گذرواژه برای آن ارسال می‌شود.'); } catch (x) { setErr(friendlyError(x)); } finally { setBusy(false); }
  }
  return <form className="card center-card" onSubmit={submit} noValidate><h2>بازیابی گذرواژه</h2>
    {msg && <Alert kind="success">{msg}</Alert>}{err && <Alert kind="error">{err}</Alert>}
    <Field id="fe" label="ایمیل"><input id="fe" className="input" dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
    <button className="btn primary" disabled={busy}>ارسال پیوند بازیابی</button></form>;
}

export function ResetPassword() {
  const a = useAuth(), nav = useNavigate();
  const [p, setP] = useState(''), [c, setC] = useState(''), [err, setErr] = useState<string | null>(null), [busy, setBusy] = useState(false);
  if (a.loading) return <Spinner full />;
  if (!a.session) return <div className="card center-card"><h2>پیوند نامعتبر است</h2><p>پیوند بازیابی منقضی شده یا نامعتبر است. دوباره درخواست دهید.</p><Link className="btn" to="/forgot-password">درخواست دوباره</Link></div>;
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(null);
    if (p.length < 8 || !/[A-Za-z]/.test(p) || !/\d/.test(p)) return setErr('گذرواژه باید دست‌کم ۸ نویسه و شامل حروف و عدد باشد.');
    if (p !== c) return setErr('تکرار گذرواژه یکسان نیست.');
    setBusy(true);
    try { await updatePassword(p); nav('/library', { replace: true }); } catch (x) { setErr(friendlyError(x)); } finally { setBusy(false); }
  }
  return <form className="card center-card" onSubmit={submit} noValidate><h2>گذرواژهٔ جدید</h2>{err && <Alert kind="error">{err}</Alert>}
    <Field id="np" label="گذرواژهٔ جدید"><input id="np" className="input" dir="ltr" type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="new-password" /></Field>
    <Field id="nc" label="تکرار گذرواژه"><input id="nc" className="input" dir="ltr" type="password" value={c} onChange={(e) => setC(e.target.value)} autoComplete="new-password" /></Field>
    <button className="btn primary" disabled={busy}>ذخیرهٔ گذرواژه</button></form>;
}
