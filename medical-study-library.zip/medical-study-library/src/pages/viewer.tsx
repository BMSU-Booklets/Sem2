import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { Alert, Crumbs, Spinner, useToast } from '../components/ui';
import { fetchText, signedUrl } from '../lib/files-api';
import { getCourse, getResource, listBookmarks, setBookmark } from '../lib/content-api';
import { formatBytes, formatTime, friendlyError, TYPE_LABEL } from '../lib/fa';
import { buildSandboxDoc, SANDBOX_ATTR } from '../lib/htmlSandbox';
import type { Course, Resource } from '../lib/types';

export function ResourceViewer() {
  const { id = '' } = useParams();
  const a = useAuth(), toast = useToast();
  const [r, setR] = useState<Resource | null>(null), [course, setCourse] = useState<Course | null>(null), [err, setErr] = useState<string | null>(null), [marked, setMarked] = useState(false);
  useEffect(() => {
    setR(null); setErr(null);
    getResource(id).then(async (res) => { setR(res); setCourse(await getCourse(res.course_id).catch(() => null)); setMarked((await listBookmarks().catch(() => [] as string[])).includes(id)); })
      .catch(() => setErr('این منبع پیدا نشد یا اجازهٔ دیدن آن را ندارید.'));   // same message for "missing" and "forbidden"
  }, [id]);
  if (err) return <Alert kind="error">{err} <Link to="/library">بازگشت به کتابخانه</Link></Alert>;
  if (!r) return <Spinner />;
  const canDownload = r.allow_download || a.can('resources.edit');
  async function download() {
    try { window.location.href = await signedUrl(r!.file_path, r!.file_name); } catch (e) { toast(friendlyError(e), true); }
  }
  async function toggleMark() {
    try { await setBookmark(a.session!.user.id, r!.id, !marked); setMarked(!marked); } catch (e) { toast(friendlyError(e), true); }
  }
  return <>
    <Crumbs items={[{ to: '/library', label: 'کتابخانه' }, ...(course ? [{ to: `/course/${course.id}`, label: course.title }] : []), { label: r.title }]} />
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <div><h1 style={{ marginBottom: 0 }}>{r.title}</h1><p className="hint">{TYPE_LABEL[r.type]} · {formatBytes(r.file_size)}{r.status === 'draft' && ' · پیش‌نویس'}</p></div>
      <div className="row"><button className="btn small" aria-pressed={marked} onClick={toggleMark}>{marked ? '★ نشان‌شده' : '☆ نشان‌کردن'}</button>
        {canDownload && <button className="btn small" onClick={download}>دانلود</button>}
        <button className="btn small" onClick={() => history.back()}>بازگشت</button></div>
    </div>
    {r.description && <p>{r.description}</p>}
    <div className="card" style={{ padding: 12 }}>
      {r.type === 'html' && <HtmlViewer r={r} />}
      {r.type === 'pdf' && <PdfViewer r={r} />}
      {r.type === 'audio' && <AudioPlayer r={r} />}
      {r.type === 'image' && <ImageViewer r={r} />}
      {r.type === 'document' && <div className="empty">این نوع سند در مرورگر نمایش داده نمی‌شود.{canDownload ? <p><button className="btn primary" onClick={download}>دانلود فایل</button></p> : <p>دانلود برای شما فعال نیست.</p>}</div>}
    </div>
  </>;
}

function LoadGate({ label, onLoad, children, loaded, busy }: { label: string; onLoad: () => void; children: React.ReactNode; loaded: boolean; busy: boolean }) {
  // Large files are fetched only when the user asks (saves mobile data).
  if (loaded) return <>{children}</>;
  return <div className="empty"><button className="btn primary" onClick={onLoad} disabled={busy}>{busy ? 'در حال بارگذاری…' : label}</button></div>;
}

function HtmlViewer({ r }: { r: Resource }) {
  const [doc, setDoc] = useState<string | null>(null), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  const load = async () => { setBusy(true); try { setDoc(buildSandboxDoc(await fetchText(r.file_path))); } catch (e) { setErr(friendlyError(e)); } finally { setBusy(false); } };
  return <>{err && <Alert kind="error">{err}</Alert>}
    <LoadGate label="باز کردن جزوه" onLoad={load} loaded={doc !== null} busy={busy}>
      {/* sandbox WITHOUT allow-same-origin: opaque origin, cannot reach the app's session or DOM */}
      <iframe className="viewer-frame" title={r.title} sandbox={SANDBOX_ATTR} srcDoc={doc ?? ''} referrerPolicy="no-referrer" />
    </LoadGate></>;
}

function PdfViewer({ r }: { r: Resource }) {
  // Fetched as a blob on demand: object storage may send a CSP "sandbox" header that stops PDFs rendering in frames.
  const [url, setUrl] = useState<string | null>(null), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  useEffect(() => () => { if (url) URL.revokeObjectURL(url); }, [url]);
  const load = async () => {
    setBusy(true);
    try {
      const res = await fetch(await signedUrl(r.file_path)); if (!res.ok) throw new Error('forbidden');
      setUrl(URL.createObjectURL(new Blob([await res.arrayBuffer()], { type: 'application/pdf' })));
    } catch (e) { setErr(friendlyError(e)); } finally { setBusy(false); }
  };
  const openTab = async () => { try { window.open(await signedUrl(r.file_path), '_blank', 'noopener'); } catch (e) { setErr(friendlyError(e)); } };
  return <>{err && <Alert kind="error">{err}</Alert>}
    <LoadGate label="نمایش PDF" onLoad={load} loaded={url !== null} busy={busy}>
      <iframe className="viewer-frame" title={r.title} src={url ?? ''} />
      <p className="hint">اگر PDF در این دستگاه نمایش داده نشد، <button className="btn small" onClick={openTab}>در برگهٔ جدید باز کنید</button> (پیوند فقط ۶۰ ثانیه معتبر است).</p>
    </LoadGate></>;
}

function ImageViewer({ r }: { r: Resource }) {
  const [url, setUrl] = useState<string | null>(null), [err, setErr] = useState<string | null>(null);
  const small = r.file_size < 1_500_000;
  const load = async () => { try { setUrl(await signedUrl(r.file_path)); } catch (e) { setErr(friendlyError(e)); } };
  useEffect(() => { if (small) void load(); /* eslint-disable-next-line */ }, [r.id]);
  return <>{err && <Alert kind="error">{err}</Alert>}
    <LoadGate label="نمایش تصویر" onLoad={load} loaded={url !== null} busy={false}><img src={url ?? ''} alt={r.title} style={{ display: 'block', margin: '0 auto', borderRadius: 12 }} /></LoadGate></>;
}

export function AudioPlayer({ r }: { r: Resource }) {
  const el = useRef<HTMLAudioElement>(null);
  const [url, setUrl] = useState<string | null>(null), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false), [t, setT] = useState(0), [d, setD] = useState(0), [rate, setRate] = useState(1);
  const load = async () => { setBusy(true); try { setUrl(await signedUrl(r.file_path)); } catch (e) { setErr(friendlyError(e)); } finally { setBusy(false); } };
  useEffect(() => { if (url && el.current) void el.current.play().catch(() => {}); }, [url]);
  return <div className="audio-box">{err && <Alert kind="error">{err}</Alert>}
    <LoadGate label="پخش صوت" onLoad={load} loaded={url !== null} busy={busy}>
      <audio ref={el} src={url ?? undefined} preload="metadata" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}
        onTimeUpdate={(e) => setT(e.currentTarget.currentTime)} onLoadedMetadata={(e) => setD(e.currentTarget.duration)} onError={() => setErr('پخش فایل ممکن نشد. صفحه را دوباره باز کنید.')} />
      <div className="row" style={{ marginBottom: 10 }}>
        <button className="btn primary icon-btn" aria-label={playing ? 'توقف' : 'پخش'} onClick={() => (playing ? el.current?.pause() : void el.current?.play())}>{playing ? '⏸' : '▶'}</button>
        <span className="ltr" aria-live="off">{formatTime(t)} / {formatTime(d)}</span>
        <label className="row" style={{ marginInlineStart: 'auto' }}>سرعت
          <select className="input" style={{ width: 90, minHeight: 36 }} value={rate} onChange={(e) => { const v = +e.target.value; setRate(v); if (el.current) el.current.playbackRate = v; }}>
            {[0.75, 1, 1.25, 1.5, 2].map((s) => <option key={s} value={s}>{s}×</option>)}</select></label>
      </div>
      <input type="range" aria-label="موقعیت پخش" min={0} max={d || 0} step={0.1} value={t} style={{ width: '100%', direction: 'ltr' }}
        onChange={(e) => { const v = +e.target.value; setT(v); if (el.current) el.current.currentTime = v; }} />
    </LoadGate></div>;
}
