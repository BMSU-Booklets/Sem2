import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { Alert, Confirm, Empty, Field, Spinner, useToast } from '../../components/ui';
import { updateResource } from '../../lib/admin-api';
import { listCategories, listCourses, listResources } from '../../lib/content-api';
import { formatBytes, formatDate, friendlyError, TYPE_ICON, TYPE_LABEL } from '../../lib/fa';
import { deleteResource } from '../../lib/files-api';
import type { Category, Course, Resource } from '../../lib/types';

export function Resources() {
  const a = useAuth(), toast = useToast();
  const [items, setItems] = useState<Resource[] | null>(null), [courses, setCourses] = useState<Course[]>([]), [cats, setCats] = useState<Category[]>([]), [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState(''), [edit, setEdit] = useState<(Resource & { tagText: string }) | null>(null), [del, setDel] = useState<Resource | null>(null);
  const load = async () => { try { const [r, c, g] = await Promise.all([listResources({ includeDrafts: true }), listCourses(true), listCategories()]); setItems(r); setCourses(c); setCats(g); } catch (e) { setErr(friendlyError(e)); } };
  useEffect(() => { void load(); }, []);
  const shown = useMemo(() => (items ?? []).filter((r) => r.title.toLowerCase().includes(q.trim().toLowerCase())), [items, q]);
  const cname = (id: string) => courses.find((c) => c.id === id)?.title ?? '';
  async function save() {
    if (!edit) return;
    try {
      const patch: Parameters<typeof updateResource>[1] = { title: edit.title.trim(), description: edit.description, course_id: edit.course_id, category_id: edit.category_id, allow_download: edit.allow_download, restricted: edit.restricted,
        tags: edit.tagText.split(/[,،]/).map((t) => t.trim()).filter(Boolean).slice(0, 20) };
      if (a.can('resources.publish')) patch.status = edit.status;
      await updateResource(edit.id, patch); toast('ذخیره شد.'); setEdit(null); await load();
    } catch (e) { toast(friendlyError(e), true); }
  }
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!items) return <Spinner />;
  return <>
    <div className="toolbar"><input className="input" type="search" aria-label="جستجو" placeholder="جستجوی منبع…" value={q} onChange={(e) => setQ(e.target.value)} />
      {(a.can('resources.upload') || a.can('resources.edit')) && <Link className="btn primary" to="/admin/upload">+ بارگذاری منبع</Link>}</div>
    {shown.length === 0 && <Empty icon="🗂️" title="منبعی وجود ندارد">از بخش «بارگذاری» اولین فایل را اضافه کنید.</Empty>}
    {shown.map((r) => <div key={r.id} className="card" style={{ marginBottom: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div><h3 style={{ margin: 0 }}>{TYPE_ICON[r.type]} {r.title} <span className={`badge ${r.status === 'published' ? 'ok' : 'warn'}`}>{r.status === 'published' ? 'منتشرشده' : 'پیش‌نویس'}</span></h3>
          <span className="hint">{TYPE_LABEL[r.type]} · {formatBytes(r.file_size)} · {cname(r.course_id)} · {formatDate(r.updated_at)} · نسخهٔ {r.version}</span></div>
        <div className="row">
          {a.can('resources.edit') && <button className="btn small" onClick={() => setEdit({ ...r, tagText: r.tags.join('، ') })}>ویرایش</button>}
          {a.can('resources.edit') && <Link className="btn small" to={`/admin/upload?replace=${r.id}`}>جایگزینی فایل</Link>}
          <Link className="btn small" to={`/resource/${r.id}`}>مشاهده</Link>
          {a.can('resources.delete') && <button className="btn small danger" onClick={() => setDel(r)}>حذف</button>}</div>
      </div>
      {edit?.id === r.id && <div style={{ marginTop: 14 }}>
        <Field id="et" label="عنوان"><input id="et" className="input" maxLength={200} value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} /></Field>
        <Field id="ed" label="توضیح"><textarea id="ed" className="input" maxLength={2000} value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
        <div className="row"><Field id="ec" label="درس"><select id="ec" className="input" value={edit.course_id} onChange={(e) => setEdit({ ...edit, course_id: e.target.value, category_id: null })}>{courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select></Field>
          <Field id="eg" label="دسته"><select id="eg" className="input" value={edit.category_id ?? ''} onChange={(e) => setEdit({ ...edit, category_id: e.target.value || null })}><option value="">بدون دسته</option>{cats.filter((g) => g.course_id === edit.course_id).map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select></Field></div>
        <Field id="ea" label="برچسب‌ها" hint="با ویرگول جدا کنید"><input id="ea" className="input" value={edit.tagText} onChange={(e) => setEdit({ ...edit, tagText: e.target.value })} /></Field>
        <div className="field"><label><input type="checkbox" checked={edit.status === 'published'} disabled={!a.can('resources.publish')} onChange={(e) => setEdit({ ...edit, status: e.target.checked ? 'published' : 'draft' })} /> منتشر شود{!a.can('resources.publish') && ' (مجوز انتشار ندارید)'}</label></div>
        <div className="field"><label><input type="checkbox" checked={edit.allow_download} onChange={(e) => setEdit({ ...edit, allow_download: e.target.checked })} /> دانلود مجاز باشد</label></div>
        <div className="field"><label><input type="checkbox" checked={edit.restricted} onChange={(e) => setEdit({ ...edit, restricted: e.target.checked })} /> دسترسی محدود (فقط کاربران انتخاب‌شده)</label></div>
        <div className="row"><button className="btn primary" onClick={save}>ذخیره</button><button className="btn" onClick={() => setEdit(null)}>انصراف</button></div>
      </div>}
    </div>)}
    {del && <Confirm danger title="حذف منبع" message={`«${del.title}» و فایل آن برای همیشه حذف می‌شود. این کار قابل بازگشت نیست.`} confirmLabel="حذف دائمی" onCancel={() => setDel(null)}
      onConfirm={async () => { const r = del; setDel(null); try { await deleteResource(r.id); toast('حذف شد.'); await load(); } catch (e) { toast(friendlyError(e), true); } }} />}
  </>;
}
