import { useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { Alert, Field, useToast } from '../../components/ui';
import { listCategories, listCourses } from '../../lib/content-api';
import { formatBytes, friendlyError } from '../../lib/fa';
import { callResourceAdmin, clientCheck, uploadPending } from '../../lib/files-api';
import type { Category, Course } from '../../lib/types';

export function Upload() {
  const a = useAuth(), toast = useToast(), nav = useNavigate();
  const [params] = useSearchParams();
  const replaceId = params.get('replace');
  const [courses, setCourses] = useState<Course[]>([]), [cats, setCats] = useState<Category[]>([]);
  const [f, setF] = useState({ title: '', description: '', courseId: '', categoryId: '', tags: '', publish: false, download: a.settings?.default_allow_download ?? false, restricted: false });
  const [file, setFile] = useState<File | null>(null), [pct, setPct] = useState(0), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null), [over, setOver] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { Promise.all([listCourses(true), listCategories()]).then(([c, g]) => { setCourses(c); setCats(g); setF((x) => ({ ...x, courseId: x.courseId || c[0]?.id || '' })); }).catch((e) => setErr(friendlyError(e))); }, []);
  function pick(x: File | undefined) { if (!x) return; const m = clientCheck(x); if (m) { setErr(m); return; } setErr(null); setFile(x); if (!f.title && !replaceId) setF((s) => ({ ...s, title: x.name.replace(/\.[^.]+$/, '') })); }
  async function submit() {
    setErr(null);
    if (!file) return setErr('فایل را انتخاب کنید.');
    if (!replaceId && (!f.title.trim() || !f.courseId)) return setErr('عنوان و درس لازم است.');
    setBusy(true); setPct(0);
    try {
      const path = await uploadPending(file, a.session!.user.id, setPct);
      await callResourceAdmin({ action: 'register', pendingPath: path, replaceResourceId: replaceId, title: f.title, description: f.description, courseId: f.courseId,
        categoryId: f.categoryId || null, tags: f.tags.split(/[,،]/).map((t) => t.trim()).filter(Boolean), status: f.publish ? 'published' : 'draft', allowDownload: f.download, restricted: f.restricted });
      toast(replaceId ? 'فایل جایگزین شد.' : 'منبع بارگذاری شد.'); nav('/admin/resources');
    } catch (e) { setErr(friendlyError(e)); } finally { setBusy(false); }
  }
  return <div className="card">
    <h2>{replaceId ? 'جایگزینی فایل منبع' : 'بارگذاری منبع جدید'}</h2>
    {err && <Alert kind="error">{err}</Alert>}
    <div className={`dropzone ${over ? 'over' : ''}`} role="button" tabIndex={0} onClick={() => input.current?.click()} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && input.current?.click()}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)} onDrop={(e) => { e.preventDefault(); setOver(false); pick(e.dataTransfer.files[0]); }}>
      {file ? <b>{file.name} ({formatBytes(file.size)})</b> : <>فایل را اینجا رها کنید یا برای انتخاب بزنید<br /><span className="hint">HTML، PDF، صوت (MP3/M4A/WAV)، تصویر، DOCX/PPTX/XLSX · تا ۵۰ مگابایت</span></>}
      <input ref={input} type="file" hidden accept=".html,.htm,.pdf,.mp3,.m4a,.wav,.aac,.png,.jpg,.jpeg,.webp,.gif,.docx,.pptx,.xlsx" onChange={(e) => pick(e.target.files?.[0])} />
    </div>
    {busy && <div style={{ marginTop: 12 }}><div className="progress" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}><i style={{ width: `${pct}%` }} /></div><span className="hint">در حال بارگذاری… {pct}٪</span></div>}
    {!replaceId && <div style={{ marginTop: 18 }}>
      <Field id="ut" label="عنوان منبع"><input id="ut" className="input" maxLength={200} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
      <Field id="ud" label="توضیح"><textarea id="ud" className="input" maxLength={2000} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <div className="row"><Field id="uc" label="درس"><select id="uc" className="input" value={f.courseId} onChange={(e) => setF({ ...f, courseId: e.target.value, categoryId: '' })}>{courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select></Field>
        <Field id="ug" label="دسته‌بندی"><select id="ug" className="input" value={f.categoryId} onChange={(e) => setF({ ...f, categoryId: e.target.value })}><option value="">بدون دسته</option>{cats.filter((g) => g.course_id === f.courseId).map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select></Field></div>
      <Field id="ua" label="برچسب‌ها" hint="با ویرگول جدا کنید"><input id="ua" className="input" value={f.tags} onChange={(e) => setF({ ...f, tags: e.target.value })} /></Field>
      <div className="field"><label><input type="checkbox" checked={f.publish} disabled={!a.can('resources.publish')} onChange={(e) => setF({ ...f, publish: e.target.checked })} /> بلافاصله منتشر شود{!a.can('resources.publish') && ' (مجوز انتشار ندارید؛ به‌صورت پیش‌نویس ذخیره می‌شود)'}</label></div>
      <div className="field"><label><input type="checkbox" checked={f.download} onChange={(e) => setF({ ...f, download: e.target.checked })} /> دانلود برای دانشجویان مجاز باشد</label></div>
      <div className="field"><label><input type="checkbox" checked={f.restricted} onChange={(e) => setF({ ...f, restricted: e.target.checked })} /> دسترسی محدود (فقط کاربران انتخاب‌شده)</label></div>
    </div>}
    <button className="btn primary" onClick={submit} disabled={busy}>{busy ? 'در حال ارسال…' : replaceId ? 'جایگزینی فایل' : 'بارگذاری'}</button>
  </div>;
}
