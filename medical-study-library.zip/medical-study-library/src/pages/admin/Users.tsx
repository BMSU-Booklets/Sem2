import { useEffect, useMemo, useState } from 'react';
import { Alert, Confirm, Spinner, useToast } from '../../components/ui';
import { adminUsers, grantPermission, revokePermission, setRole, setStatus } from '../../lib/admin-api';
import { formatDate, friendlyError } from '../../lib/fa';
import { PERMISSIONS, type AccountStatus, type AdminUser, type AppRole } from '../../lib/types';

const STATUS_LABEL: Record<AccountStatus, string> = { pending: 'در انتظار تأیید', active: 'فعال', suspended: 'معلق', rejected: 'ردشده' };
const STATUS_CLASS: Record<AccountStatus, string> = { pending: 'warn', active: 'ok', suspended: 'bad', rejected: 'bad' };

export function Users() {
  const toast = useToast();
  const [users, setUsers] = useState<AdminUser[] | null>(null), [err, setErr] = useState<string | null>(null), [q, setQ] = useState(''), [filter, setFilter] = useState<'all' | AccountStatus>('all');
  const [ask, setAsk] = useState<{ title: string; message: string; danger?: boolean; run: () => Promise<void> } | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const load = () => adminUsers().then(setUsers).catch((e) => setErr(friendlyError(e)));
  useEffect(() => { void load(); }, []);
  const shown = useMemo(() => (users ?? []).filter((u) => (filter === 'all' || u.status === filter) && `${u.full_name} ${u.email}`.toLowerCase().includes(q.trim().toLowerCase())), [users, q, filter]);
  async function act(fn: () => Promise<void>, ok: string) { try { await fn(); toast(ok); await load(); } catch (e) { toast(friendlyError(e), true); } }
  const confirmStatus = (u: AdminUser, s: AccountStatus, label: string, danger = false) => setAsk({
    title: `${label}؟`, message: `${label} برای «${u.full_name || u.email}»`, danger, run: () => act(() => setStatus(u.id, s), 'انجام شد.') });
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!users) return <Spinner />;
  return <>
    <div className="toolbar"><input className="input" type="search" aria-label="جستجوی کاربر" placeholder="جستجوی نام یا ایمیل…" value={q} onChange={(e) => setQ(e.target.value)} />
      <select className="input" style={{ flex: '0 1 180px' }} aria-label="فیلتر وضعیت" value={filter} onChange={(e) => setFilter(e.target.value as 'all' | AccountStatus)}>
        <option value="all">همهٔ وضعیت‌ها</option>{(Object.keys(STATUS_LABEL) as AccountStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select></div>
    {shown.length === 0 && <div className="card empty">کاربری پیدا نشد.</div>}
    {shown.map((u) => <div key={u.id} className="card" style={{ marginBottom: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div><h3 style={{ margin: 0 }}>{u.full_name || '—'} <span className={`badge ${STATUS_CLASS[u.status]}`}>{STATUS_LABEL[u.status]}</span> {u.role === 'owner' && <span className="badge">مدیر اصلی</span>}{u.role === 'content_manager' && <span className="badge">مدیر محتوا</span>}</h3>
          <span className="ltr hint">{u.email}</span> <span className="hint">· ثبت‌نام: {formatDate(u.created_at)}{!u.email_confirmed && ' · ایمیل تأییدنشده'}</span></div>
        {u.role !== 'owner' && <div className="row">
          {(u.status === 'pending' || u.status === 'rejected') && <button className="btn small primary" disabled={!u.email_confirmed} onClick={() => confirmStatus(u, 'active', 'تأیید کاربر')}>تأیید</button>}
          {u.status === 'pending' && <button className="btn small danger" onClick={() => confirmStatus(u, 'rejected', 'رد درخواست', true)}>رد</button>}
          {u.status === 'active' && <button className="btn small danger" onClick={() => confirmStatus(u, 'suspended', 'تعلیق حساب', true)}>تعلیق</button>}
          {u.status === 'suspended' && <button className="btn small" onClick={() => confirmStatus(u, 'active', 'فعال‌سازی مجدد')}>فعال‌سازی مجدد</button>}
          <button className="btn small" onClick={() => setOpen(open === u.id ? null : u.id)} aria-expanded={open === u.id}>نقش و مجوزها</button></div>}
      </div>
      {open === u.id && u.role !== 'owner' && <div style={{ marginTop: 12 }}>
        <div className="field"><label htmlFor={`r${u.id}`}>نقش</label>
          <select id={`r${u.id}`} className="input" value={u.role} onChange={(e) => { const r = e.target.value as AppRole; setAsk({ title: 'تغییر نقش؟', message: 'نقش کاربر تغییر می‌کند.', run: () => act(() => setRole(u.id, r), 'نقش تغییر کرد.') }); }}>
            <option value="student">دانشجو</option><option value="content_manager">مدیر محتوا</option></select></div>
        <div className="chips" role="group" aria-label="مجوزها">{PERMISSIONS.map((p) => { const on = u.permissions.includes(p.key);
          return <button key={p.key} className="chip" aria-pressed={on} disabled={u.status !== 'active'} onClick={() => act(() => (on ? revokePermission(u.id, p.key) : grantPermission(u.id, p.key)), on ? 'مجوز لغو شد.' : 'مجوز داده شد.')}>{p.label}</button>; })}</div>
        {u.status !== 'active' && <p className="hint">مجوزها فقط برای حساب‌های فعال اعمال می‌شوند.</p>}
      </div>}
    </div>)}
    {ask && <Confirm title={ask.title} message={ask.message} danger={ask.danger} onCancel={() => setAsk(null)} onConfirm={async () => { const r = ask.run; setAsk(null); await r(); }} />}
  </>;
}
