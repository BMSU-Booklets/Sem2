import { useEffect, useState } from 'react';
import { Alert, Spinner, useToast } from '../../components/ui';
import { adminUsers, listAccess, setAccess } from '../../lib/admin-api';
import { listCourses, listResources } from '../../lib/content-api';
import { friendlyError } from '../../lib/fa';
import type { AdminUser, Course, Resource } from '../../lib/types';

export function Access() {
  const toast = useToast();
  const [users, setUsers] = useState<AdminUser[] | null>(null), [courses, setCourses] = useState<Course[]>([]), [resources, setResources] = useState<Resource[]>([]), [err, setErr] = useState<string | null>(null);
  const [kind, setKind] = useState<'course' | 'resource'>('course'), [target, setTarget] = useState(''), [granted, setGranted] = useState<Set<string>>(new Set());
  useEffect(() => { Promise.all([adminUsers(), listCourses(true), listResources({ includeDrafts: true })]).then(([u, c, r]) => { setUsers(u.filter((x) => x.status === 'active' && x.role !== 'owner')); setCourses(c); setResources(r); setTarget(c[0]?.id ?? ''); }).catch((e) => setErr(friendlyError(e))); }, []);
  useEffect(() => { if (target) listAccess(kind, target).then((l) => setGranted(new Set(l))).catch(() => setGranted(new Set())); }, [kind, target]);
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!users) return <Spinner />;
  const options = kind === 'course' ? courses.map((c) => ({ id: c.id, label: `${c.title}${c.restricted ? ' (محدود)' : ''}` })) : resources.map((r) => ({ id: r.id, label: `${r.title}${r.restricted ? ' (محدود)' : ''}` }));
  async function toggle(u: AdminUser) {
    const on = !granted.has(u.id);
    try { await setAccess(kind, target, u.id, on); setGranted((s) => { const n = new Set(s); on ? n.add(u.id) : n.delete(u.id); return n; }); } catch (e) { toast(friendlyError(e), true); }
  }
  return <div className="card">
    <p className="hint">این فهرست فقط برای درس‌ها یا منابعی که «دسترسی محدود» دارند اثر می‌گذارد. گزینهٔ محدودبودن را در ویرایش درس یا منبع روشن کنید.</p>
    <div className="row"><select className="input" style={{ maxWidth: 160 }} aria-label="نوع" value={kind} onChange={(e) => { setKind(e.target.value as 'course' | 'resource'); setTarget((e.target.value === 'course' ? courses[0]?.id : resources[0]?.id) ?? ''); }}><option value="course">درس</option><option value="resource">منبع</option></select>
      <select className="input" style={{ flex: 1 }} aria-label="هدف" value={target} onChange={(e) => setTarget(e.target.value)}>{options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select></div>
    <div className="table-wrap" style={{ marginTop: 14 }}><table><thead><tr><th>کاربر</th><th>ایمیل</th><th>دسترسی</th></tr></thead><tbody>
      {users.length === 0 && <tr><td colSpan={3}>کاربر فعالی وجود ندارد.</td></tr>}
      {users.map((u) => <tr key={u.id}><td>{u.full_name}</td><td className="ltr">{u.email}</td><td><input type="checkbox" aria-label={`دسترسی ${u.full_name}`} checked={granted.has(u.id)} onChange={() => toggle(u)} disabled={!target} /></td></tr>)}</tbody></table></div>
  </div>;
}
