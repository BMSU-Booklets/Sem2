import { Navigate, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { Crumbs } from '../../components/ui';

export function AdminLayout() {
  const a = useAuth(), loc = useLocation();
  const tabs: [string, string, boolean][] = [
    ['/admin', 'نمای کلی', a.isOwner], ['/admin/users', 'کاربران', a.isOwner],
    ['/admin/courses', 'دروس و دسته‌ها', a.can('courses.manage') || a.can('categories.manage')],
    ['/admin/resources', 'منابع', a.can('resources.edit') || a.can('resources.delete') || a.can('resources.publish')],
    ['/admin/upload', 'بارگذاری', a.can('resources.upload') || a.can('resources.edit')],
    ['/admin/access', 'دسترسی‌ها', a.isOwner],
  ];
  const first = tabs.find((t) => t[2]);
  if (loc.pathname === '/admin' && !a.isOwner) return first ? <Navigate to={first[0]} replace /> : <Navigate to="/unauthorized" replace />;
  return <>
    <Crumbs items={[{ to: '/library', label: 'کتابخانه' }, { label: 'مدیریت' }]} />
    <nav className="admin-nav" aria-label="بخش‌های مدیریت">{tabs.filter((t) => t[2]).map(([to, label]) => <NavLink key={to} to={to} end={to === '/admin'} className={({ isActive }) => (isActive ? 'active' : '')}>{label}</NavLink>)}</nav>
    <Outlet />
  </>;
}
