import { useEffect, useState } from 'react';
import { useAuth } from '../../auth/AuthContext';
import { Alert, Confirm, Empty, Field, Spinner, useToast } from '../../components/ui';
import { deleteCategory, deleteCourse, saveCategory, saveCourse } from '../../lib/admin-api';
import { listCategories, listCourses } from '../../lib/content-api';
import { friendlyError } from '../../lib/fa';
import { uploadBranding } from '../../lib/files-api';
import type { Category, Course } from '../../lib/types';

export function Courses() {
  const a = useAuth(), toast = useToast();
  const [courses, setCourses] = useState<Course[] | null>(null), [cats, setCats] = useState<Category[]>([]), [err, setErr] = useState<string | null>(null);
  const [edit, setEdit] = useState<Partial<Course> | null>(null), [ask, setAsk] = useState<{ msg: string; run: () => Promise<void> } | null>(null);
  const [newCat, setNewCat] = useState<Record<string, string>>({});
  const load = async () => { try { const [c, g] = await Promise.all([listCourses(true), listCategories()]); setCourses(c); setCats(g); } catch (e) { setErr(friendlyError(e)); } };
  useEffect(() => { void load(); }, []);
  async function act(fn: () => Promise<void>, ok: string) { try { await fn(); toast(ok); await load(); } catch (e) { toast(friendlyError(e), true); } }
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!courses) return <Spinner />;
  const canC = a.can('courses.manage'), canG = a.can('categories.manage');
  return <>
    {canC && <p><button className="btn primary" onClick={() => setEdit({ title: '', description: '', icon: '📘', sort_order: courses.length + 1, restricted: false })}>+ درس جدید</button></p>}
    {edit && <div className="card" style={{ marginBottom: 18 }}>
      <h3>{edit.id ? 'ویرایش درس' : 'درس جدید'}</h3>
      <Field id="ct" label="عنوان"><input id="ct" className="input" maxLength={120} value={edit.title ?? ''} onChange={(e) => setEdit({ ...edit, title: e.target.value })} /></Field>
      <Field id="cd" label="توضیح کوتاه"><input id="cd" className="input" maxLength={500} value={edit.description ?? ''} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
      <div className="row"><Field id="ci" label="آیکون (ایموجی)"><input id="ci" className="input" style={{ width: 120 }} maxLength={8} value={edit.icon ?? ''} onChange={(e) => setEdit({ ...edit, icon: e.target.value })} /></Field>
        <Field id="co" label="ترتیب"><input id="co" className="input" style={{ width: 100 }} type="number" value={edit.sort_order ?? 0} onChange={(e) => setEdit({ ...edit, sort_order: +e.target.value })} /></Field></div>
      <Field id="cm" label="تصویر درس (اختیاری)" hint="جایگزین آیکون می‌شود"><input id="cm" className="input" type="file" accept="image/png,image/jpeg,image/webp" onChange={async (e) => { const f = e.target.files?.[0]; if (f) try { setEdit({ ...edit, image_url: await uploadBranding(f) }); } catch (x) { toast(friendlyError(x), true); } }} /></Field>
      <div className="field"><label><input type="checkbox" checked={!!edit.restricted} onChange={(e) => setEdit({ ...edit, restricted: e.target.checked })} /> دسترسی محدود (فقط کاربران انتخاب‌شده در بخش «دسترسی‌ها»)</label></div>
      {edit.id && <div className="field"><label><input type="checkbox" checked={!!edit.is_archived} onChange={(e) => setEdit({ ...edit, is_archived: e.target.checked })} /> بایگانی (برای دانشجویان نمایش داده نشود)</label></div>}
      <div className="row"><button className="btn primary" onClick={() => { if (!edit.title?.trim()) return toast('عنوان لازم است.', true); void act(async () => { await saveCourse(edit as Course); setEdit(null); }, 'ذخیره شد.'); }}>ذخیره</button><button className="btn" onClick={() => setEdit(null)}>انصراف</button></div>
    </div>}
    {courses.length === 0 && <Empty icon="📚" title="درسی وجود ندارد">با دکمهٔ «درس جدید» شروع کنید.</Empty>}
    {courses.map((c) => <div key={c.id} className="card" style={{ marginBottom: 14 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0 }}>{c.icon} {c.title} {c.is_archived && <span className="badge warn">بایگانی</span>} {c.restricted && <span className="badge">محدود</span>}</h3>
        {canC && <div className="row"><button className="btn small" onClick={() => setEdit(c)}>ویرایش</button>
          <button className="btn small danger" onClick={() => setAsk({ msg: `درس «${c.title}» همراه با همهٔ دسته‌ها و منابعش حذف شود؟ فایل‌های منابع باید جداگانه از بخش منابع حذف شوند.`, run: () => act(() => deleteCourse(c.id), 'درس حذف شد.') })}>حذف</button></div>}
      </div>
      <div className="chips" style={{ marginTop: 10 }}>{cats.filter((g) => g.course_id === c.id).map((g) => <span key={g.id} className="chip" style={{ cursor: 'default' }}>{g.title}
        {canG && <> <button className="btn small icon-btn" style={{ minHeight: 24, padding: '0 6px' }} aria-label={`ویرایش ${g.title}`} onClick={() => { const t = prompt('عنوان جدید دسته', g.title); if (t?.trim()) void act(() => saveCategory({ ...g, title: t.trim() }), 'ذخیره شد.'); }}>✎</button>
          <button className="btn small icon-btn" style={{ minHeight: 24, padding: '0 6px' }} aria-label={`حذف ${g.title}`} onClick={() => setAsk({ msg: `دستهٔ «${g.title}» حذف شود؟ منابع آن بدون دسته می‌مانند.`, run: () => act(() => deleteCategory(g.id), 'دسته حذف شد.') })}>✕</button></>}</span>)}</div>
      {canG && <div className="row"><input className="input" style={{ maxWidth: 260 }} placeholder="دستهٔ جدید…" aria-label={`دستهٔ جدید برای ${c.title}`} value={newCat[c.id] ?? ''} onChange={(e) => setNewCat({ ...newCat, [c.id]: e.target.value })} />
        <button className="btn small" onClick={() => { const t = (newCat[c.id] ?? '').trim(); if (t) void act(async () => { await saveCategory({ course_id: c.id, title: t, sort_order: cats.filter((g) => g.course_id === c.id).length + 1 }); setNewCat({ ...newCat, [c.id]: '' }); }, 'دسته افزوده شد.'); }}>افزودن دسته</button></div>}
    </div>)}
    {ask && <Confirm danger title="تأیید حذف" message={ask.msg} confirmLabel="حذف" onCancel={() => setAsk(null)} onConfirm={async () => { const r = ask.run; setAsk(null); await r(); }} />}
  </>;
}
