import { useEffect, useState } from 'react';
import { useAuth } from '../../auth/AuthContext';
import { Alert, Field, Spinner, useToast } from '../../components/ui';
import { adminStats, auditLogs, updateSettings } from '../../lib/admin-api';
import { formatBytes, formatDate, friendlyError, toFaDigits } from '../../lib/fa';
import { uploadBranding } from '../../lib/files-api';
import type { AdminStats } from '../../lib/types';

export function Overview() {
  const a = useAuth(), toast = useToast();
  const [s, setS] = useState<AdminStats | null>(null), [err, setErr] = useState<string | null>(null);
  const [logs, setLogs] = useState<Awaited<ReturnType<typeof auditLogs>>>([]);
  const [f, setF] = useState({ site_title: a.settings!.site_title, site_subtitle: a.settings!.site_subtitle, registration_open: a.settings!.registration_open, default_allow_download: a.settings!.default_allow_download, logo_url: a.settings!.logo_url });
  useEffect(() => { adminStats().then(setS).catch((e) => setErr(friendlyError(e))); auditLogs().then(setLogs).catch(() => {}); }, []);
  async function save() {
    try { await updateSettings({ ...f, site_title: f.site_title.trim(), site_subtitle: f.site_subtitle.trim() }); await a.refresh(); toast('تنظیمات ذخیره شد.'); } catch (e) { toast(friendlyError(e), true); }
  }
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!s) return <Spinner />;
  const tiles: [string, string][] = [['کاربران', toFaDigits(s.users_total)], ['در انتظار تأیید', toFaDigits(s.users_pending)], ['فعال', toFaDigits(s.users_active)], ['معلق', toFaDigits(s.users_suspended)],
    ['دروس', toFaDigits(s.courses)], ['منابع', toFaDigits(s.resources)], ['حجم ذخیره‌شده', formatBytes(Number(s.storage_bytes))]];
  return <>
    <div className="grid cols">{tiles.map(([k, v]) => <div key={k} className="card stat"><b>{v}</b>{k}</div>)}</div>
    <h2 style={{ marginTop: 28 }}>تنظیمات سایت</h2>
    <div className="card">
      <Field id="st" label="عنوان سایت"><input id="st" className="input" value={f.site_title} maxLength={120} onChange={(e) => setF({ ...f, site_title: e.target.value })} /></Field>
      <Field id="ss" label="زیرعنوان"><input id="ss" className="input" value={f.site_subtitle} maxLength={300} onChange={(e) => setF({ ...f, site_subtitle: e.target.value })} /></Field>
      <Field id="sl" label="لوگو" hint="PNG، JPG یا WebP تا ۲ مگابایت (عمومی است)">
        <input id="sl" className="input" type="file" accept="image/png,image/jpeg,image/webp" onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; try { setF({ ...f, logo_url: await uploadBranding(file) }); toast('لوگو بارگذاری شد؛ برای اعمال، ذخیره کنید.'); } catch (x) { toast(friendlyError(x), true); } }} /></Field>
      <div className="field"><label><input type="checkbox" checked={f.registration_open} onChange={(e) => setF({ ...f, registration_open: e.target.checked })} /> ثبت‌نام کاربران جدید باز باشد</label></div>
      <div className="field"><label><input type="checkbox" checked={f.default_allow_download} onChange={(e) => setF({ ...f, default_allow_download: e.target.checked })} /> دانلود برای منابع جدید به‌طور پیش‌فرض مجاز باشد</label></div>
      <button className="btn primary" onClick={save}>ذخیرهٔ تنظیمات</button>
    </div>
    <h2 style={{ marginTop: 28 }}>گزارش فعالیت‌های اخیر</h2>
    <div className="card table-wrap"><table><thead><tr><th>تاریخ</th><th>عملیات</th><th>بخش</th><th>جزئیات</th></tr></thead><tbody>
      {logs.length === 0 && <tr><td colSpan={4}>موردی ثبت نشده است.</td></tr>}
      {logs.map((l) => <tr key={l.id}><td>{formatDate(l.created_at)}</td><td>{l.action}</td><td>{l.target_type}</td><td>{l.details?.title ?? l.details?.status ?? ''}</td></tr>)}</tbody></table></div>
  </>;
}
