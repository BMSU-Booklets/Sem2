import React from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/vazirmatn/400.css';
import '@fontsource/vazirmatn/500.css';
import '@fontsource/vazirmatn/700.css';
import './styles/global.css';
import App from './App';
import { AuthProvider } from './auth/AuthContext';
import { ToastProvider } from './components/ui';

createRoot(document.getElementById('root')!).render(
  <React.StrictMode><ToastProvider><AuthProvider><App /></AuthProvider></ToastProvider></React.StrictMode>,
);
