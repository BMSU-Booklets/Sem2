import { supabase } from './supabase';
import type { AccountStatus, AdminStats, AdminUser, AppRole, Category, Course, Resource, SiteSettings } from './types';

const ok = <T,>(r: { data: T | null; error: unknown }): T => { if (r.error) throw r.error; return r.data as T; };
const run = async (p: PromiseLike<{ error: unknown }>) => { const r = await p; if (r.error) throw r.error; };

export const adminStats = async () => ok(await supabase.rpc('admin_stats')) as AdminStats;
export const adminUsers = async () => ok(await supabase.rpc('admin_list_users')) as AdminUser[];
export const setStatus = (target: string, s: AccountStatus) => run(supabase.rpc('admin_set_account_status', { target, new_status: s }));
export const setRole = (target: string, r: AppRole) => run(supabase.rpc('admin_set_role', { target, new_role: r }));
export const grantPermission = (target: string, perm: string) => run(supabase.rpc('admin_grant_permission', { target, perm }));
export const revokePermission = (target: string, perm: string) => run(supabase.rpc('admin_revoke_permission', { target, perm }));

export const saveCourse = async (c: Partial<Course> & { title: string }) =>
  c.id ? run(supabase.from('courses').update({ title: c.title, description: c.description, icon: c.icon, image_url: c.image_url ?? null, sort_order: c.sort_order, is_archived: c.is_archived, restricted: c.restricted }).eq('id', c.id))
       : run(supabase.from('courses').insert({ title: c.title, description: c.description ?? '', icon: c.icon ?? '📘', sort_order: c.sort_order ?? 0, restricted: c.restricted ?? false }));
export const deleteCourse = (id: string) => run(supabase.from('courses').delete().eq('id', id));
export const saveCategory = async (c: Partial<Category> & { course_id: string; title: string }) =>
  c.id ? run(supabase.from('categories').update({ title: c.title, sort_order: c.sort_order }).eq('id', c.id))
       : run(supabase.from('categories').insert({ course_id: c.course_id, title: c.title, sort_order: c.sort_order ?? 0, parent_id: c.parent_id ?? null }));
export const deleteCategory = (id: string) => run(supabase.from('categories').delete().eq('id', id));

export const updateResource = (id: string, patch: Partial<Pick<Resource, 'title' | 'description' | 'course_id' | 'category_id' | 'tags' | 'status' | 'allow_download' | 'restricted'>>) =>
  run(supabase.from('resources').update(patch).eq('id', id));

export const updateSettings = (s: Partial<SiteSettings>) => run(supabase.from('site_settings').update(s).eq('id', 1));

export const listAccess = async (kind: 'course' | 'resource', id: string): Promise<string[]> => {
  const t = kind === 'course' ? 'course_access' : 'resource_access', col = kind === 'course' ? 'course_id' : 'resource_id';
  return ((ok(await supabase.from(t).select('user_id').eq(col, id)) ?? []) as { user_id: string }[]).map((r) => r.user_id);
};
export const setAccess = (kind: 'course' | 'resource', id: string, userId: string, on: boolean) => {
  const t = kind === 'course' ? 'course_access' : 'resource_access', col = kind === 'course' ? 'course_id' : 'resource_id';
  return on ? run(supabase.from(t).insert({ [col]: id, user_id: userId })) : run(supabase.from(t).delete().eq(col, id).eq('user_id', userId));
};
export const auditLogs = async () => ok(await supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(100)) as
  { id: number; actor_id: string | null; action: string; target_type: string; details: Record<string, string>; created_at: string }[];
