// Untrusted uploaded HTML is NEVER inserted into the app DOM. It is rendered in an <iframe srcdoc>
// with sandbox="allow-scripts" and WITHOUT allow-same-origin, so the frame gets an opaque origin:
// it cannot read the parent's cookies/localStorage/Supabase session or touch the parent DOM.
// A restrictive CSP <meta> is injected as a second layer: no network, no nested frames, no forms.
export const SANDBOX_ATTR = 'allow-scripts allow-popups';   // deliberately no allow-same-origin, no allow-top-navigation

export const SANDBOX_CSP = [
  "default-src 'none'",
  "script-src 'unsafe-inline'",
  "style-src 'unsafe-inline'",
  'img-src data: blob:',
  'font-src data:',
  'media-src data: blob:',
  "connect-src 'none'",
  "frame-src 'none'",
  "form-action 'none'",
  "base-uri 'none'",
].join('; ');

const META = `<meta http-equiv="Content-Security-Policy" content="${SANDBOX_CSP}">`;

export function buildSandboxDoc(html: string): string {
  // strip any <base> and author CSP metas first, then put OUR CSP at the very top of the document
  let h = html
    .replace(/<base\b[^>]*>/gi, '')
    .replace(/<meta\b[^>]*http-equiv\s*=\s*["']?content-security-policy["']?[^>]*>/gi, '');
  if (/<head\b[^>]*>/i.test(h)) return h.replace(/<head\b[^>]*>/i, (m) => `${m}${META}`);
  if (/<html\b[^>]*>/i.test(h)) return h.replace(/<html\b[^>]*>/i, (m) => `${m}<head>${META}</head>`);
  return `<!doctype html><html><head>${META}</head><body>${h}</body></html>`;
}
