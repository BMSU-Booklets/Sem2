import { supabase } from './supabase';
import type { Category, Course, Profile, Resource, SiteSettings } from './types';

const ok = <T,>(r: { data: T | null; error: unknown }): T => { if (r.error) throw r.error; return r.data as T; };

export const getSettings = async () =>
  ok(await supabase.from('site_settings').select('site_title,site_subtitle,logo_url,registration_open,default_allow_download').eq('id', 1).single()) as SiteSettings;

export const getMyProfile = async (uid: string) =>
  ok(await supabase.from('profiles').select('id,full_name,email,status,created_at').eq('id', uid).single()) as Profile;

export async function getMyAccess(uid: string): Promise<{ role: string; permissions: string[] }> {
  const [r, p] = await Promise.all([
    supabase.from('user_roles').select('role').eq('user_id', uid).single(),
    supabase.from('user_permissions').select('permission_key').eq('user_id', uid),
  ]);
  const role = (ok(r) as { role: string }).role;
  const perms = (ok(p) ?? []) as { permission_key: string }[];
  return { role, permissions: perms.map((x) => x.permission_key) };
}
export const updateMyName = async (uid: string, fullName: string) =>
  ok(await supabase.from('profiles').update({ full_name: fullName.trim() }).eq('id', uid).select('id').single());

export const listCourses = async (includeArchived = false) => {
  let q = supabase.from('courses').select('*').order('sort_order').order('created_at');
  if (!includeArchived) q = q.eq('is_archived', false);
  return ok(await q) as Course[];
};
export const getCourse = async (id: string) => ok(await supabase.from('courses').select('*').eq('id', id).single()) as Course;
export const listCategories = async (courseId?: string) => {
  let q = supabase.from('categories').select('*').order('sort_order').order('title');
  if (courseId) q = q.eq('course_id', courseId);
  return ok(await q) as Category[];
};
export const listResources = async (opts: { courseId?: string; categoryId?: string; includeDrafts?: boolean } = {}) => {
  let q = supabase.from('resources').select('*').order('created_at', { ascending: false });
  if (opts.courseId) q = q.eq('course_id', opts.courseId);
  if (opts.categoryId) q = q.eq('category_id', opts.categoryId);
  if (!opts.includeDrafts) q = q.eq('status', 'published');
  return ok(await q) as Resource[];
};
export const getResource = async (id: string) => ok(await supabase.from('resources').select('*').eq('id', id).single()) as Resource;

export const listBookmarks = async () => ((ok(await supabase.from('bookmarks').select('resource_id')) ?? []) as { resource_id: string }[]).map((b) => b.resource_id);
export async function setBookmark(uid: string, resourceId: string, on: boolean) {
  const r = on
    ? await supabase.from('bookmarks').insert({ user_id: uid, resource_id: resourceId })
    : await supabase.from('bookmarks').delete().eq('user_id', uid).eq('resource_id', resourceId);
  if (r.error) throw r.error;
}
