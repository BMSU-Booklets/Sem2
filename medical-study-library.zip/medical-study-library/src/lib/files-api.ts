import { functionsUrl, supabase } from './supabase';
import { ALLOWED_EXTENSIONS, extensionOf, MAX_FILE_BYTES, safeFileName } from '../../supabase/functions/_shared/fileKind.ts';

/** Short-lived (60 s) URL, issued only if the storage RLS policy lets THIS user read the object. */
export async function signedUrl(path: string, download?: string | boolean): Promise<string> {
  const { data, error } = await supabase.storage.from('library').createSignedUrl(path, 60, download ? { download } : undefined);
  if (error || !data) throw error ?? new Error('forbidden');
  return data.signedUrl;
}
export async function fetchText(path: string): Promise<string> {
  const res = await fetch(await signedUrl(path));
  if (!res.ok) throw new Error('forbidden');
  return res.text();
}

export function clientCheck(file: File): string | null {
  if (!ALLOWED_EXTENSIONS.includes(extensionOf(file.name))) return 'این نوع فایل پشتیبانی نمی‌شود.';
  if (file.size > MAX_FILE_BYTES) return 'حجم فایل بیشتر از ۵۰ مگابایت است.';
  if (file.size === 0) return 'فایل خالی است.';
  return null;   // UX only — the Edge Function re-validates everything
}

/** Upload with progress (XHR gives upload progress events) into the caller's own pending/ folder. */
export async function uploadPending(file: File, uid: string, onProgress: (pct: number) => void): Promise<string> {
  const { data: sess } = await supabase.auth.getSession();
  const token = sess.session?.access_token;
  if (!token) throw new Error('unauthenticated');
  const path = `pending/${uid}/${crypto.randomUUID()}-${safeFileName(file.name)}`.replace(/[^\w./-]/g, '_');
  const base = `${import.meta.env.VITE_SUPABASE_URL as string}/storage/v1`;
  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${base}/object/library/${path}`);
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.setRequestHeader('apikey', import.meta.env.VITE_SUPABASE_ANON_KEY as string);
    xhr.setRequestHeader('x-upsert', 'false');
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(xhr.responseText || 'upload failed')));
    xhr.onerror = () => reject(new Error('network'));
    xhr.send(file);
  });
  return path;
}

export async function callResourceAdmin<T = { id: string }>(body: Record<string, unknown>): Promise<T> {
  const { data: sess } = await supabase.auth.getSession();
  const res = await fetch(`${functionsUrl}/resource-admin`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${sess.session?.access_token ?? ''}`, apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error ?? `http_${res.status}`);
  return json as T;
}
export const deleteResource = (resourceId: string) => callResourceAdmin({ action: 'delete', resourceId });

export async function uploadBranding(file: File): Promise<string> {
  const ext = extensionOf(file.name);
  if (!['png', 'jpg', 'jpeg', 'webp'].includes(ext) || file.size > 2 * 1024 * 1024) throw new Error('mime');
  const path = `${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from('branding').upload(path, file, { contentType: file.type });
  if (error) throw error;
  return supabase.storage.from('branding').getPublicUrl(path).data.publicUrl;
}
