export type AccountStatus = 'pending' | 'active' | 'suspended' | 'rejected';
export type AppRole = 'owner' | 'content_manager' | 'student';
export type ResourceType = 'html' | 'pdf' | 'audio' | 'image' | 'document';

export interface Profile { id: string; full_name: string; email: string; status: AccountStatus; created_at: string }
export interface Course {
  id: string; title: string; description: string; icon: string; image_url: string | null;
  sort_order: number; is_archived: boolean; restricted: boolean;
}
export interface Category { id: string; course_id: string; parent_id: string | null; title: string; sort_order: number }
export interface Resource {
  id: string; course_id: string; category_id: string | null; title: string; description: string;
  type: ResourceType; tags: string[]; file_path: string; file_name: string; file_size: number;
  mime_type: string; version: number; status: 'draft' | 'published'; allow_download: boolean;
  restricted: boolean; created_at: string; updated_at: string;
}
export interface AdminUser {
  id: string; full_name: string; email: string; status: AccountStatus; role: AppRole;
  permissions: string[]; email_confirmed: boolean; created_at: string;
}
export interface SiteSettings {
  site_title: string; site_subtitle: string; logo_url: string | null;
  registration_open: boolean; default_allow_download: boolean;
}
export interface AdminStats {
  users_total: number; users_pending: number; users_active: number; users_suspended: number;
  courses: number; resources: number; storage_bytes: number;
}
export const PERMISSIONS: { key: string; label: string }[] = [
  { key: 'courses.manage', label: 'مدیریت دروس' },
  { key: 'categories.manage', label: 'مدیریت دسته‌بندی‌ها' },
  { key: 'resources.upload', label: 'بارگذاری منبع' },
  { key: 'resources.edit', label: 'ویرایش و جایگزینی منبع' },
  { key: 'resources.publish', label: 'انتشار منبع' },
  { key: 'resources.delete', label: 'حذف منبع' },
];
