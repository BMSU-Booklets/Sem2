import { supabase } from './supabase';

const redirectBase = () => `${window.location.origin}${window.location.pathname}`;

export async function signUp(fullName: string, email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({
    email: email.trim(), password,
    options: { data: { full_name: fullName.trim() }, emailRedirectTo: `${redirectBase()}#/verified` },
  });
  if (error) throw error;
  // Supabase returns an obfuscated user with no identities for an already-registered address.
  if (data.user && data.user.identities && data.user.identities.length === 0) throw new Error('already registered');
}
export async function signIn(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
  if (error) throw error;
}
export const signOut = () => supabase.auth.signOut();
export async function resendVerification(email: string) {
  const { error } = await supabase.auth.resend({ type: 'signup', email: email.trim(), options: { emailRedirectTo: `${redirectBase()}#/verified` } });
  if (error) throw error;
}
export async function requestPasswordReset(email: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${redirectBase()}#/reset-password` });
  if (error) throw error;
}
export async function updatePassword(password: string) {
  const { error } = await supabase.auth.updateUser({ password });
  if (error) throw error;
}
