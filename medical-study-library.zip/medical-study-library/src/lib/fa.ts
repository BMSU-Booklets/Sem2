// Persian helpers: digits, formatting, validation and friendly error messages.
const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
export const toFaDigits = (v: string | number): string => String(v).replace(/\d/g, (d) => FA_DIGITS[+d]);

export function formatBytes(n: number): string {
  if (n < 1024) return `${toFaDigits(n)} بایت`;
  const units = ['کیلوبایت', 'مگابایت', 'گیگابایت'];
  let v = n / 1024, i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${toFaDigits(v.toFixed(v < 10 ? 1 : 0))} ${units[i]}`;
}
export const formatDate = (iso: string): string =>
  new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium' }).format(new Date(iso));
export const formatTime = (s: number): string => {
  if (!isFinite(s)) return '۰۰:۰۰';
  const m = Math.floor(s / 60), r = Math.floor(s % 60);
  return toFaDigits(`${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`);
};

export interface FieldErrors { [field: string]: string | undefined }
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateRegister(v: { fullName: string; email: string; password: string; confirm: string }): FieldErrors {
  const e: FieldErrors = {};
  if (v.fullName.trim().length < 3) e.fullName = 'نام و نام خانوادگی را کامل وارد کنید.';
  if (!EMAIL.test(v.email.trim())) e.email = 'نشانی ایمیل معتبر نیست.';
  if (v.password.length < 8) e.password = 'گذرواژه باید دست‌کم ۸ نویسه باشد.';
  else if (!/[A-Za-z]/.test(v.password) || !/\d/.test(v.password)) e.password = 'گذرواژه باید شامل حروف و عدد باشد.';
  if (v.confirm !== v.password) e.confirm = 'تکرار گذرواژه با گذرواژه یکسان نیست.';
  return e;
}
export function validateLogin(v: { email: string; password: string }): FieldErrors {
  const e: FieldErrors = {};
  if (!EMAIL.test(v.email.trim())) e.email = 'نشانی ایمیل معتبر نیست.';
  if (!v.password) e.password = 'گذرواژه را وارد کنید.';
  return e;
}

/** Map backend/auth error messages to safe Persian text. Unknown errors never leak details. */
export function friendlyError(err: unknown): string {
  const m = String((err as { message?: string })?.message ?? err ?? '').toLowerCase();
  if (m.includes('invalid login')) return 'ایمیل یا گذرواژه درست نیست.';
  if (m.includes('email not confirmed')) return 'ابتدا ایمیل خود را با پیوند ارسال‌شده تأیید کنید.';
  if (m.includes('already registered') || m.includes('already been registered')) return 'با این ایمیل پیش‌تر ثبت‌نام شده است.';
  if (m.includes('registration_closed') || m.includes('database error saving new user')) return 'ثبت‌نام در حال حاضر بسته است.';
  if (m.includes('rate limit') || m.includes('too many') || m.includes('429')) return 'درخواست‌ها زیاد بوده است؛ کمی بعد دوباره تلاش کنید.';
  if (m.includes('forbidden') || m.includes('42501') || m.includes('row-level security')) return 'اجازهٔ انجام این کار را ندارید.';
  if (m.includes('email_not_verified')) return 'ایمیل این کاربر هنوز تأیید نشده است.';
  if (m.includes('file_too_large') || m.includes('exceeded the maximum')) return 'حجم فایل بیشتر از حد مجاز است.';
  if (m.includes('unsupported_or_mismatched_type') || m.includes('mime')) return 'نوع یا محتوای فایل مجاز نیست.';
  if (m.includes('network') || m.includes('failed to fetch')) return 'ارتباط با سرور برقرار نشد. اینترنت خود را بررسی کنید.';
  return 'خطایی رخ داد. دوباره تلاش کنید.';
}

export const TYPE_LABEL: Record<string, string> = {
  html: 'جزوهٔ تعاملی', pdf: 'PDF', audio: 'صوت', image: 'تصویر', document: 'سند',
};
export const TYPE_ICON: Record<string, string> = { html: '🌐', pdf: '📕', audio: '🎧', image: '🖼️', document: '📄' };
