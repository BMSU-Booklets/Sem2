import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';

export function Spinner({ full }: { full?: boolean }) {
  return <div role="status" aria-label="در حال بارگذاری" style={full ? { minHeight: '60vh', display: 'grid', placeItems: 'center' } : undefined}><div className="spinner" /></div>;
}
export const Alert = ({ kind = 'warn', children }: { kind?: 'warn' | 'error' | 'success'; children: ReactNode }) =>
  <div className={`alert ${kind === 'warn' ? '' : kind}`} role={kind === 'error' ? 'alert' : 'status'}>{children}</div>;

export function Empty({ icon = '📭', title, children }: { icon?: string; title: string; children?: ReactNode }) {
  return <div className="empty card"><div className="big" aria-hidden>{icon}</div><h3>{title}</h3>{children}</div>;
}
export function Field({ label, error, hint, children, id }: { label: string; error?: string; hint?: string; children: ReactNode; id: string }) {
  return <div className="field"><label htmlFor={id}>{label}</label>{children}{hint && !error && <span className="hint">{hint}</span>}{error && <span className="field-error" id={`${id}-err`}>{error}</span>}</div>;
}
export function Crumbs({ items }: { items: { to?: string; label: string }[] }) {
  return <nav className="crumbs" aria-label="مسیر">{items.map((it, i) => <span key={i}>{it.to ? <Link to={it.to}>{it.label}</Link> : it.label}{i < items.length - 1 && ' ‹ '}</span>)}</nav>;
}

// ---- toasts ----
type Toast = { id: number; text: string; error?: boolean };
const ToastCtx = createContext<(text: string, error?: boolean) => void>(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((text: string, error?: boolean) => {
    const id = Date.now() + Math.random();
    setItems((a) => [...a, { id, text, error }]);
    window.setTimeout(() => setItems((a) => a.filter((t) => t.id !== id)), 4000);
  }, []);
  return <ToastCtx.Provider value={push}>{children}<div className="toasts" aria-live="polite">{items.map((t) => <div key={t.id} className={`toast ${t.error ? 'error' : ''}`}>{t.text}</div>)}</div></ToastCtx.Provider>;
}

// ---- confirmation dialog ----
export function Confirm({ title, message, confirmLabel = 'تأیید', danger, onConfirm, onCancel }:
  { title: string; message: string; confirmLabel?: string; danger?: boolean; onConfirm: () => void; onCancel: () => void }) {
  const ref = useRef<HTMLButtonElement>(null);
  useEffect(() => { ref.current?.focus(); const k = (e: KeyboardEvent) => e.key === 'Escape' && onCancel(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onCancel]);
  return <div className="modal-back" onClick={onCancel}><div className="modal" role="alertdialog" aria-modal="true" aria-labelledby="cf-t" onClick={(e) => e.stopPropagation()}>
    <h3 id="cf-t">{title}</h3><p>{message}</p>
    <div className="row"><button ref={ref} className={`btn ${danger ? 'danger' : 'primary'}`} onClick={onConfirm}>{confirmLabel}</button><button className="btn" onClick={onCancel}>انصراف</button></div>
  </div></div>;
}
