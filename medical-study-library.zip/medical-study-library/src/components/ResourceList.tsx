import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Empty } from './ui';
import { formatBytes, formatDate, TYPE_ICON, TYPE_LABEL } from '../lib/fa';
import type { Category, Course, Resource } from '../lib/types';

type Sort = 'date' | 'title' | 'type' | 'course' | 'category';

export function ResourceList({ items, courses, categories, bookmarked, onToggleBookmark, showDrafts }: {
  items: Resource[]; courses?: Course[]; categories?: Category[]; bookmarked?: Set<string>;
  onToggleBookmark?: (id: string, on: boolean) => void; showDrafts?: boolean;
}) {
  const [q, setQ] = useState(''), [type, setType] = useState<string>('all'), [sort, setSort] = useState<Sort>('date');
  const cName = useMemo(() => new Map((courses ?? []).map((c) => [c.id, c.title])), [courses]);
  const gName = useMemo(() => new Map((categories ?? []).map((c) => [c.id, c.title])), [categories]);
  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const f = items.filter((r) => (type === 'all' || r.type === type) &&
      (!needle || `${r.title} ${r.description} ${r.tags.join(' ')}`.toLowerCase().includes(needle)));
    const key = (r: Resource) => sort === 'title' ? r.title : sort === 'type' ? r.type : sort === 'course' ? cName.get(r.course_id) ?? '' : sort === 'category' ? gName.get(r.category_id ?? '') ?? '' : '';
    return [...f].sort((a, b) => sort === 'date' ? b.created_at.localeCompare(a.created_at) : key(a).localeCompare(key(b), 'fa'));
  }, [items, q, type, sort, cName, gName]);

  return <>
    <div className="toolbar">
      <input className="input" type="search" placeholder="جستجو در عنوان، توضیح و برچسب‌ها…" aria-label="جستجو" value={q} onChange={(e) => setQ(e.target.value)} />
      <select className="input" style={{ flex: '0 1 170px' }} aria-label="مرتب‌سازی" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
        <option value="date">جدیدترین</option><option value="title">عنوان</option><option value="type">نوع منبع</option>
        {courses && <option value="course">درس</option>}{categories && <option value="category">دسته‌بندی</option>}
      </select>
    </div>
    <div className="chips" role="group" aria-label="فیلتر نوع منبع">
      {['all', 'html', 'pdf', 'audio', 'image', 'document'].map((t) =>
        <button key={t} className="chip" aria-pressed={type === t} onClick={() => setType(t)}>{t === 'all' ? 'همه' : `${TYPE_ICON[t]} ${TYPE_LABEL[t]}`}</button>)}
    </div>
    {shown.length === 0 ? <Empty icon="🗂️" title="منبعی پیدا نشد">{items.length === 0 ? 'هنوز منبعی در این بخش منتشر نشده است.' : 'جستجو یا فیلتر را تغییر دهید.'}</Empty> :
      shown.map((r) => <div key={r.id} className="card res-row">
        <span className="ico" aria-hidden>{TYPE_ICON[r.type]}</span>
        <Link to={`/resource/${r.id}`} className="body" style={{ color: 'inherit' }}>
          <h3 style={{ margin: 0 }}>{r.title}{showDrafts && r.status === 'draft' && <span className="badge warn" style={{ marginInlineStart: 8 }}>پیش‌نویس</span>}</h3>
          <p>{TYPE_LABEL[r.type]} · {formatBytes(r.file_size)} · {formatDate(r.created_at)}{cName.get(r.course_id) ? ` · ${cName.get(r.course_id)}` : ''}</p>
          {r.description && <p>{r.description.slice(0, 140)}</p>}
        </Link>
        {onToggleBookmark && <button className="btn small icon-btn" aria-pressed={bookmarked?.has(r.id)} aria-label={bookmarked?.has(r.id) ? 'حذف نشان' : 'نشان‌کردن'}
          onClick={() => onToggleBookmark(r.id, !bookmarked?.has(r.id))}>{bookmarked?.has(r.id) ? '★' : '☆'}</button>}
      </div>)}
  </>;
}
