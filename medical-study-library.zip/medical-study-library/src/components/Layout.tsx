import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { signOut } from '../lib/auth-api';
import { useTheme } from '../lib/theme';

export function Layout() {
  const a = useAuth(), nav = useNavigate();
  const [theme, toggle] = useTheme();
  const adminOk = a.isOwner || ['courses.manage', 'categories.manage', 'resources.upload', 'resources.edit'].some((p) => a.can(p));
  return <>
    <header className="topbar">
      <Link to="/" className="brand">{a.settings?.logo_url ? <img src={a.settings.logo_url} alt="" /> : <span className="logo" aria-hidden>📚</span>}<span>{a.settings?.site_title}</span></Link>
      <nav aria-label="منوی اصلی">
        {a.session && a.profile?.status === 'active' && <>
          <NavLink className="btn small" to="/library">کتابخانه</NavLink>
          <NavLink className="btn small" to="/bookmarks">نشان‌شده‌ها</NavLink>
          {adminOk && <NavLink className="btn small" to="/admin">مدیریت</NavLink>}
          <NavLink className="btn small" to="/profile">پروفایل</NavLink>
        </>}
        <button className="btn small icon-btn" onClick={toggle} aria-label={theme === 'light' ? 'حالت تیره' : 'حالت روشن'}>{theme === 'light' ? '🌙' : '☀️'}</button>
        {a.session ? <button className="btn small" onClick={async () => { await signOut(); nav('/'); }}>خروج</button>
                   : <><Link className="btn small" to="/login">ورود</Link><Link className="btn small primary" to="/register">ثبت‌نام</Link></>}
      </nav>
    </header>
    <main className="page"><Outlet /></main>
  </>;
}
