import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { Spinner } from '../components/ui';

/** Route guards are a UX layer. Real enforcement is Row Level Security + the Edge Function. */
export function RequireAuth() {
  const a = useAuth(), loc = useLocation();
  if (a.loading) return <Spinner full />;
  if (!a.session) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />;
  if (!a.emailVerified) return <Navigate to="/verify" replace />;
  return <Outlet />;
}

export function RequireActive() {
  const a = useAuth();
  if (a.loading) return <Spinner full />;
  if (!a.profile) return <Spinner full />;
  if (a.profile.status === 'pending') return <Navigate to="/pending" replace />;
  if (a.profile.status === 'rejected') return <Navigate to="/rejected" replace />;
  if (a.profile.status === 'suspended') return <Navigate to="/suspended" replace />;
  return <Outlet />;
}

export function RequirePermission({ any }: { any: string[] | 'owner' }) {
  const a = useAuth();
  const allowed = any === 'owner' ? a.isOwner : a.isOwner || any.some((p) => a.can(p));
  return allowed ? <Outlet /> : <Navigate to="/unauthorized" replace />;
}
