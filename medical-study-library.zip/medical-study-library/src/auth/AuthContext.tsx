import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { getMyAccess, getMyProfile, getSettings } from '../lib/content-api';
import type { Profile, SiteSettings } from '../lib/types';

interface AuthState {
  loading: boolean;
  session: Session | null;
  profile: Profile | null;
  role: string | null;
  permissions: string[];
  settings: SiteSettings | null;
  emailVerified: boolean;
  isOwner: boolean;
  can: (perm: string) => boolean;      // UI hint only; the database re-checks every operation
  refresh: () => Promise<void>;
}
const Ctx = createContext<AuthState | null>(null);
export const useAuth = () => { const c = useContext(Ctx); if (!c) throw new Error('AuthProvider missing'); return c; };

const DEFAULT_SETTINGS: SiteSettings = {
  site_title: 'کتابخانه دروس پزشکی',
  site_subtitle: 'منابع آموزشی پزشکی، جزوات و فایل‌های کلاس را یک‌جا مرور کنید',
  logo_url: null, registration_open: true, default_allow_download: false,
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [role, setRole] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<string[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  const loadAccount = useCallback(async (s: Session | null) => {
    if (!s) { setProfile(null); setRole(null); setPermissions([]); return; }
    try {
      const [p, a] = await Promise.all([getMyProfile(s.user.id), getMyAccess(s.user.id)]);
      setProfile(p); setRole(a.role); setPermissions(a.permissions);
    } catch { setProfile(null); setRole(null); setPermissions([]); }
  }, []);

  useEffect(() => {
    getSettings().then(setSettings).catch(() => setSettings(DEFAULT_SETTINGS));
    supabase.auth.getSession().then(async ({ data }) => { setSession(data.session); await loadAccount(data.session); setLoading(false); });
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, s) => {
      setSession(s);
      // defer: never call supabase inside the callback synchronously (deadlock-prone)
      setTimeout(() => { void loadAccount(s); }, 0);
    });
    return () => sub.subscription.unsubscribe();
  }, [loadAccount]);

  // Re-validate status/permissions on focus and every minute, so suspension reaches open sessions.
  useEffect(() => {
    if (!session) return;
    const again = () => { void supabase.auth.getUser().then(({ error }) => { if (error) void supabase.auth.signOut(); }); void loadAccount(session); };
    const id = window.setInterval(again, 60_000);
    window.addEventListener('focus', again);
    return () => { window.clearInterval(id); window.removeEventListener('focus', again); };
  }, [session, loadAccount]);

  const value = useMemo<AuthState>(() => ({
    loading, session, profile, role, permissions, settings: settings ?? DEFAULT_SETTINGS,
    emailVerified: Boolean(session?.user.email_confirmed_at),
    isOwner: role === 'owner' && profile?.status === 'active',
    can: (perm) => profile?.status === 'active' && (role === 'owner' || permissions.includes(perm)),
    refresh: async () => { await loadAccount(session); setSettings(await getSettings().catch(() => DEFAULT_SETTINGS)); },
  }), [loading, session, profile, role, permissions, settings, loadAccount]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
