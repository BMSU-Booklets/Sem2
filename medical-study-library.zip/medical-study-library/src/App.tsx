import { HashRouter, Route, Routes } from 'react-router-dom';
import { RequireActive, RequireAuth, RequirePermission } from './auth/guards';
import { Layout } from './components/Layout';
import { AdminLayout } from './pages/admin/AdminLayout';
import { Access } from './pages/admin/Access';
import { Courses } from './pages/admin/Courses';
import { Overview } from './pages/admin/Overview';
import { Resources } from './pages/admin/Resources';
import { Upload } from './pages/admin/Upload';
import { Users } from './pages/admin/Users';
import { ForgotPassword, Landing, Login, Register, ResetPassword, Verified, VerifyNotice } from './pages/auth';
import { Bookmarks, CoursePage, Home, Profile } from './pages/library';
import { NotFound, Pending, Rejected, Suspended, Unauthorized } from './pages/status';
import { ResourceViewer } from './pages/viewer';

// HashRouter: client-side routes keep working on GitHub Pages (no server rewrites needed).
export default function App() {
  return <HashRouter><Routes><Route element={<Layout />}>
    <Route path="/" element={<Landing />} />
    <Route path="/register" element={<Register />} />
    <Route path="/login" element={<Login />} />
    <Route path="/forgot-password" element={<ForgotPassword />} />
    <Route path="/reset-password" element={<ResetPassword />} />
    <Route path="/verified" element={<Verified />} />
    <Route element={<RequireAuth />}>
      <Route path="/verify" element={<VerifyNotice />} />
      <Route path="/pending" element={<Pending />} />
      <Route path="/rejected" element={<Rejected />} />
      <Route path="/suspended" element={<Suspended />} />
      <Route element={<RequireActive />}>
        <Route path="/library" element={<Home />} />
        <Route path="/course/:courseId" element={<CoursePage />} />
        <Route path="/course/:courseId/category/:categoryId" element={<CoursePage />} />
        <Route path="/resource/:id" element={<ResourceViewer />} />
        <Route path="/bookmarks" element={<Bookmarks />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/unauthorized" element={<Unauthorized />} />
        <Route path="/admin" element={<AdminLayout />}>
          <Route element={<RequirePermission any="owner" />}>
            <Route index element={<Overview />} /><Route path="users" element={<Users />} /><Route path="access" element={<Access />} />
          </Route>
          <Route element={<RequirePermission any={['courses.manage', 'categories.manage']} />}><Route path="courses" element={<Courses />} /></Route>
          <Route element={<RequirePermission any={['resources.edit', 'resources.delete', 'resources.publish']} />}><Route path="resources" element={<Resources />} /></Route>
          <Route element={<RequirePermission any={['resources.upload', 'resources.edit']} />}><Route path="upload" element={<Upload />} /></Route>
        </Route>
      </Route>
    </Route>
    <Route path="*" element={<NotFound />} />
  </Route></Routes></HashRouter>;
}
