import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' keeps asset URLs relative, so the build works on GitHub Pages under any repository
// name (https://USER.github.io/medical-study-library/) and on any other static host.
export default defineConfig({ base: './', plugins: [react()] });
