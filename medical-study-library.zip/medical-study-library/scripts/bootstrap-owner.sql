-- ONE-TIME: make yourself the owner (run in Supabase Dashboard > SQL Editor, which runs as postgres).
-- Prerequisites: you already registered on the site AND clicked the verification link in your email.
select public.bootstrap_owner('YOUR-EMAIL@example.com');   -- <- replace with the email you registered with

-- Afterwards, remove the mechanism so it can never be used again:
drop function public.bootstrap_owner(text);
