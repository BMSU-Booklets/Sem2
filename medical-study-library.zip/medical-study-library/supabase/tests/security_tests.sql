-- Security verification for RLS / grants / RPCs.  NOT executed in the authoring sandbox (no Postgres there).
-- Run in the Supabase SQL editor on a DEV project after migrations 0001+0002. Everything is rolled back.
-- Success = the script finishes and prints "ALL SECURITY CHECKS PASSED"; a failure raises an exception naming the check.
begin;

create function public._t_denied(sql text, label text) returns void language plpgsql as $$
begin
  begin execute sql; exception when others then return; end;
  raise exception 'FAILED (should be denied): %', label;
end $$;
create function public._t_rows(sql text) returns int language plpgsql as $$
declare n int; begin execute sql; get diagnostics n = row_count; return n; end $$;
create function public._t_eq(actual bigint, expected bigint, label text) returns void language plpgsql as $$
begin if actual is distinct from expected then raise exception 'FAILED: % (got %, expected %)', label, actual, expected; end if; end $$;
grant execute on function public._t_denied(text,text), public._t_rows(text), public._t_eq(bigint,bigint,text) to authenticated, anon;

-- ---------- fixtures (as postgres) ----------
insert into auth.users (id, email, email_confirmed_at) values
  ('00000000-0000-0000-0000-0000000000a1','owner@t.test', now()),
  ('00000000-0000-0000-0000-0000000000b1','student@t.test', now()),
  ('00000000-0000-0000-0000-0000000000c1','pending@t.test', now()),
  ('00000000-0000-0000-0000-0000000000d1','suspended@t.test', now()),
  ('00000000-0000-0000-0000-0000000000e1','unverified@t.test', null),
  ('00000000-0000-0000-0000-0000000000f1','manager@t.test', now());
select public.bootstrap_owner('owner@t.test');
update public.profiles set status='active' where id in ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-0000000000f1');
update public.profiles set status='suspended' where id = '00000000-0000-0000-0000-0000000000d1';
insert into public.courses(id,title) values ('10000000-0000-0000-0000-000000000001','Open course');
insert into public.courses(id,title,restricted) values ('10000000-0000-0000-0000-000000000002','Restricted course', true);
insert into public.resources(id,course_id,title,type,file_path,file_name,file_size,mime_type,status) values
  ('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','Published','pdf','resources/t1/a.pdf','a.pdf',1,'application/pdf','published'),
  ('20000000-0000-0000-0000-000000000002','10000000-0000-0000-0000-000000000001','Draft','pdf','resources/t2/b.pdf','b.pdf',1,'application/pdf','draft'),
  ('20000000-0000-0000-0000-000000000003','10000000-0000-0000-0000-000000000002','In restricted course','pdf','resources/t3/c.pdf','c.pdf',1,'application/pdf','published');
insert into storage.objects(bucket_id,name) values ('library','resources/t1/a.pdf'),('library','resources/t2/b.pdf'),('library','resources/t3/c.pdf');

do $$ begin
  perform public._t_eq((select count(*) from public.user_roles where role='owner'), 1, 'exactly one owner after bootstrap');
  begin perform public.bootstrap_owner('student@t.test'); raise exception 'FAILED: second bootstrap succeeded';
  exception when others then if sqlerrm like 'FAILED%' then raise; end if; end;
  perform public._t_eq((select has_function_privilege('authenticated','public.bootstrap_owner(text)','execute'))::int, 0, 'authenticated cannot execute bootstrap_owner');
  perform public._t_eq((select has_function_privilege('anon','public.bootstrap_owner(text)','execute'))::int, 0, 'anon cannot execute bootstrap_owner');
end $$;

-- ---------- anonymous visitor ----------
set local role anon;
select public._t_denied('select * from public.courses', 'anon reads courses');
select public._t_denied('select * from public.resources', 'anon reads resources');
select public._t_denied('select * from public.profiles', 'anon reads profiles');
select public._t_eq((select count(*) from public.site_settings), 1, 'anon can read public site settings');
select public._t_eq((select count(*) from storage.objects where bucket_id='library'), 0, 'anon sees no library objects');
reset role;

-- ---------- pending / suspended / unverified: no content ----------
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000c1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.courses), 0, 'pending user sees no courses');
select public._t_eq((select count(*) from public.resources), 0, 'pending user sees no resources');
select public._t_eq((select count(*) from storage.objects where bucket_id='library'), 0, 'pending user sees no files');
select public._t_eq((select count(*) from public.profiles), 1, 'pending user can read only own profile');
reset role;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000d1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.resources), 0, 'suspended user sees no resources');
select public._t_eq((select count(*) from storage.objects where bucket_id='library'), 0, 'suspended user sees no files');
reset role;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000e1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.resources), 0, 'unverified-email user sees no resources');
reset role;

-- ---------- approved student ----------
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.courses), 1, 'student sees only the open course');
select public._t_eq((select count(*) from public.resources), 1, 'student sees only the published resource in the open course');
select public._t_eq((select count(*) from storage.objects where bucket_id='library'), 1, 'student can read only permitted file objects');
select public._t_eq((select count(*) from public.resources where id='20000000-0000-0000-0000-000000000002'), 0, 'student cannot see drafts (ID guessing)');
select public._t_denied($$update public.profiles set status='active' where id='00000000-0000-0000-0000-0000000000c1'$$, 'student approves another user');
select public._t_denied($$update public.profiles set status='active' where id='00000000-0000-0000-0000-0000000000b1'$$, 'student edits own status');
select public._t_denied($$update public.user_roles set role='owner' where user_id='00000000-0000-0000-0000-0000000000b1'$$, 'student changes own role');
select public._t_denied($$insert into public.user_permissions(user_id,permission_key) values ('00000000-0000-0000-0000-0000000000b1','courses.manage')$$, 'student grants self permission');
select public._t_denied($$insert into public.course_access(course_id,user_id) values ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-0000000000b1')$$, 'student grants self course access');
select public._t_denied($$insert into public.courses(title) values ('hack')$$, 'student creates course');
select public._t_eq(public._t_rows($$update public.courses set title='x'$$), 0, 'student cannot edit courses (0 rows)');
select public._t_eq(public._t_rows($$delete from public.courses$$), 0, 'student cannot delete courses (0 rows)');
select public._t_denied($$insert into public.resources(course_id,title,type,file_path,file_name,file_size,mime_type) values ('10000000-0000-0000-0000-000000000001','x','pdf','p','p',1,'application/pdf')$$, 'student inserts resource row');
select public._t_eq(public._t_rows($$update public.resources set title='x'$$), 0, 'student cannot edit resources (0 rows)');
select public._t_eq(public._t_rows($$delete from public.resources$$), 0, 'student cannot delete resources (0 rows)');
select public._t_denied($$update public.resources set file_path='resources/t3/c.pdf'$$, 'student rewrites file_path');
select public._t_denied($$select public.admin_set_account_status('00000000-0000-0000-0000-0000000000c1','active')$$, 'student calls admin_set_account_status');
select public._t_denied($$select public.admin_set_role('00000000-0000-0000-0000-0000000000b1','content_manager')$$, 'student calls admin_set_role');
select public._t_denied($$select public.admin_list_users()$$, 'student lists users');
select public._t_denied($$select public.admin_stats()$$, 'student reads stats');
select public._t_eq((select count(*) from public.audit_logs), 0, 'student reads no audit logs');
select public._t_denied($$insert into public.audit_logs(action,target_type) values ('x','y')$$, 'student writes audit logs');
select public._t_denied($$insert into storage.objects(bucket_id,name) values ('library','pending/00000000-0000-0000-0000-0000000000b1/x.pdf')$$, 'student uploads to library');
select public._t_eq(public._t_rows($$update public.site_settings set site_title='hacked'$$), 0, 'student settings update affects 0 rows');
reset role;

-- ---------- owner ----------
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.resources), 3, 'owner sees all resources');
select public._t_eq((select count(*) from public.profiles), 6, 'owner sees all profiles');
select public.admin_set_account_status('00000000-0000-0000-0000-0000000000c1','active');
select public._t_denied($$select public.admin_set_account_status('00000000-0000-0000-0000-0000000000a1','suspended')$$, 'owner suspends self');
select public._t_denied($$select public.admin_set_account_status('00000000-0000-0000-0000-0000000000e1','active')$$, 'approve unverified email');
select public._t_denied($$select public.admin_set_role('00000000-0000-0000-0000-0000000000b1','owner')$$, 'owner role assignable');
select public.admin_grant_permission('00000000-0000-0000-0000-0000000000f1','resources.upload');
insert into public.course_access(course_id,user_id) values ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-0000000000b1');
reset role;

-- ---------- student after owner granted restricted-course access ----------
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.resources), 2, 'student sees restricted resource after being granted access');
reset role;

-- ---------- content manager with only resources.upload ----------
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000f1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select has_permission('resources.upload'))::int, 1, 'manager has upload');
select public._t_eq((select has_permission('resources.delete'))::int, 0, 'manager lacks delete');
select public._t_eq(public._t_rows($$delete from public.resources$$), 0, 'manager cannot delete resources');
select public._t_denied($$select public.admin_grant_permission('00000000-0000-0000-0000-0000000000f1','resources.delete')$$, 'manager grants self delete');
reset role;

-- ---------- suspension revokes access immediately ----------
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}',true);
set local role authenticated;
select public.admin_set_account_status('00000000-0000-0000-0000-0000000000b1','suspended');
reset role;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}',true);
set local role authenticated;
select public._t_eq((select count(*) from public.resources), 0, 'suspended student loses resource access at once');
select public._t_eq((select count(*) from storage.objects where bucket_id='library'), 0, 'suspended student loses file access at once');
reset role;

select 'ALL SECURITY CHECKS PASSED' as result;
rollback;
