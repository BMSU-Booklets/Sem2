-- =====================================================================
-- کتابخانه دروس پزشکی — schema, RLS, RPCs, storage policies
-- Run once in the Supabase SQL editor (or `supabase db push`).
-- Principle: deny by default. Clients get ONLY the grants listed below.
-- =====================================================================

-- ---------- enums ----------
create type public.account_status as enum ('pending','active','suspended','rejected');
create type public.app_role       as enum ('owner','content_manager','student');
create type public.resource_type  as enum ('html','pdf','audio','image','document');
create type public.publish_status as enum ('draft','published');

-- ---------- tables ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '' check (char_length(full_name) <= 120),
  email text not null,
  status public.account_status not null default 'pending',
  status_changed_by uuid references auth.users(id) on delete set null,
  status_changed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_status_idx on public.profiles(status);

create table public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'student',
  updated_at timestamptz not null default now()
);
-- at most ONE owner can ever exist
create unique index user_roles_single_owner on public.user_roles ((true)) where role = 'owner';

create table public.permissions (
  key text primary key,
  description text not null
);
insert into public.permissions(key, description) values
  ('courses.manage',    'ایجاد و ویرایش دروس'),
  ('categories.manage', 'ایجاد و ویرایش دسته‌بندی‌ها'),
  ('resources.upload',  'بارگذاری منبع جدید'),
  ('resources.edit',    'ویرایش و جایگزینی منابع'),
  ('resources.publish', 'انتشار و لغو انتشار منابع'),
  ('resources.delete',  'حذف منابع');

create table public.user_permissions (
  user_id uuid not null references auth.users(id) on delete cascade,
  permission_key text not null references public.permissions(key) on delete cascade,
  granted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key (user_id, permission_key)
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  description text not null default '' check (char_length(description) <= 500),
  icon text not null default '📘' check (char_length(icon) <= 16),
  image_url text check (image_url is null or char_length(image_url) <= 500),
  sort_order int not null default 0,
  is_archived boolean not null default false,
  restricted boolean not null default false,   -- true => only users listed in course_access
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  parent_id uuid references public.categories(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index categories_course_idx on public.categories(course_id);

create table public.resources (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  title text not null check (char_length(title) between 1 and 200),
  description text not null default '' check (char_length(description) <= 2000),
  type public.resource_type not null,
  tags text[] not null default '{}' check (cardinality(tags) <= 20),
  file_path text not null unique,
  file_name text not null,
  file_size bigint not null check (file_size >= 0),
  mime_type text not null,
  version int not null default 1,
  status public.publish_status not null default 'draft',
  allow_download boolean not null default false,
  restricted boolean not null default false,   -- true => only users listed in resource_access
  uploaded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index resources_course_idx   on public.resources(course_id);
create index resources_category_idx on public.resources(category_id);
create index resources_type_idx     on public.resources(type);

create table public.course_access (
  course_id uuid not null references public.courses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (course_id, user_id)
);
create table public.resource_access (
  resource_id uuid not null references public.resources(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (resource_id, user_id)
);
create table public.bookmarks (
  user_id uuid not null references auth.users(id) on delete cascade,
  resource_id uuid not null references public.resources(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, resource_id)
);
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  target_type text not null,
  target_id text,
  details jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs(created_at desc);

create table public.site_settings (
  id int primary key default 1 check (id = 1),
  site_title text not null default 'کتابخانه دروس پزشکی' check (char_length(site_title) <= 120),
  site_subtitle text not null default 'منابع آموزشی پزشکی، جزوات و فایل‌های کلاس را یک‌جا مرور کنید' check (char_length(site_subtitle) <= 300),
  logo_url text check (logo_url is null or char_length(logo_url) <= 500),
  registration_open boolean not null default true,
  default_allow_download boolean not null default false,
  updated_at timestamptz not null default now()
);
insert into public.site_settings(id) values (1);

-- ---------- helper functions (SECURITY DEFINER, fixed search_path) ----------
create function public.is_active_user() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from auth.users u
    join public.profiles p on p.id = u.id
    where u.id = auth.uid() and u.email_confirmed_at is not null and p.status = 'active'
  );
$$;

create function public.is_owner() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_active_user() and exists (
    select 1 from public.user_roles r where r.user_id = auth.uid() and r.role = 'owner');
$$;

create function public.has_permission(p text) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_owner() or (
    public.is_active_user() and exists (
      select 1 from public.user_permissions up
      where up.user_id = auth.uid() and up.permission_key = p));
$$;

create function public.can_view_course(cid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_active_user() and exists (
    select 1 from public.courses c where c.id = cid and (
      public.has_permission('courses.manage')
      or (not c.is_archived and (not c.restricted or exists (
            select 1 from public.course_access ca where ca.course_id = c.id and ca.user_id = auth.uid())))));
$$;

create function public.can_view_resource(rid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_active_user() and exists (
    select 1 from public.resources r join public.courses c on c.id = r.course_id
    where r.id = rid and (
      public.has_permission('resources.edit')
      or (r.status = 'published' and not c.is_archived
          and (not c.restricted or exists (select 1 from public.course_access ca where ca.course_id = c.id and ca.user_id = auth.uid()))
          and (not r.restricted or exists (select 1 from public.resource_access ra where ra.resource_id = r.id and ra.user_id = auth.uid())))));
$$;

-- ---------- triggers ----------
create function public.touch_updated_at() returns trigger language plpgsql
set search_path = '' as $$ begin new.updated_at = now(); return new; end $$;
create trigger t_touch_profiles   before update on public.profiles   for each row execute function public.touch_updated_at();
create trigger t_touch_courses    before update on public.courses    for each row execute function public.touch_updated_at();
create trigger t_touch_categories before update on public.categories for each row execute function public.touch_updated_at();
create trigger t_touch_resources  before update on public.resources  for each row execute function public.touch_updated_at();
create trigger t_touch_settings   before update on public.site_settings for each row execute function public.touch_updated_at();

-- publishing needs its own permission; file columns are immutable for browser clients
create function public.guard_resource_update() returns trigger language plpgsql security definer
set search_path = '' as $$
begin
  if new.status is distinct from old.status and not public.has_permission('resources.publish') then
    raise exception 'forbidden: resources.publish required' using errcode = '42501';
  end if;
  if (new.file_path is distinct from old.file_path or new.file_size is distinct from old.file_size
      or new.type is distinct from old.type or new.mime_type is distinct from old.mime_type
      or new.uploaded_by is distinct from old.uploaded_by or new.version is distinct from old.version
      or new.file_name is distinct from old.file_name)
     and auth.role() is distinct from 'service_role' then
    raise exception 'forbidden: file columns are immutable for clients' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger t_guard_resource_update before update on public.resources
  for each row execute function public.guard_resource_update();

create function public.audit_row() returns trigger language plpgsql security definer
set search_path = '' as $$
declare j jsonb := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
begin
  insert into public.audit_logs(actor_id, action, target_type, target_id, details)
  values (auth.uid(), lower(tg_op), tg_table_name,
          coalesce(j->>'id', (j->>'user_id') || ':' || coalesce(j->>'permission_key', '')),
          jsonb_build_object('title', j->>'title', 'status', j->>'status', 'role', j->>'role'));
  return null;
end $$;
create trigger a_courses    after insert or update or delete on public.courses         for each row execute function public.audit_row();
create trigger a_categories after insert or update or delete on public.categories      for each row execute function public.audit_row();
create trigger a_resources  after insert or update or delete on public.resources       for each row execute function public.audit_row();
create trigger a_user_perms after insert or delete          on public.user_permissions for each row execute function public.audit_row();
create trigger a_user_roles after update                    on public.user_roles       for each row execute function public.audit_row();

-- new auth user => pending profile + student role. Honors the "registration closed" setting.
create function public.handle_new_user() returns trigger language plpgsql security definer
set search_path = '' as $$
begin
  if not (select registration_open from public.site_settings where id = 1)
     and exists (select 1 from public.user_roles where role = 'owner') then
    raise exception 'registration_closed';
  end if;
  insert into public.profiles(id, email, full_name)
    values (new.id, coalesce(new.email, ''), left(coalesce(new.raw_user_meta_data->>'full_name', ''), 120));
  insert into public.user_roles(user_id, role) values (new.id, 'student');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- admin RPCs (owner only, audited) ----------
create function public.admin_set_account_status(target uuid, new_status public.account_status) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'forbidden' using errcode = '42501'; end if;
  if target = auth.uid() then raise exception 'cannot_change_own_status'; end if;
  if exists (select 1 from public.user_roles where user_id = target and role = 'owner') then
    raise exception 'cannot_change_owner'; end if;
  if new_status = 'active' and not exists (select 1 from auth.users where id = target and email_confirmed_at is not null) then
    raise exception 'email_not_verified'; end if;
  update public.profiles set status = new_status, status_changed_by = auth.uid(), status_changed_at = now() where id = target;
  if not found then raise exception 'not_found'; end if;
  insert into public.audit_logs(actor_id, action, target_type, target_id, details)
    values (auth.uid(), 'set_status', 'profiles', target::text, jsonb_build_object('status', new_status));
end $$;

create function public.admin_set_role(target uuid, new_role public.app_role) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'forbidden' using errcode = '42501'; end if;
  if new_role = 'owner' then raise exception 'owner_role_not_assignable'; end if;
  if exists (select 1 from public.user_roles where user_id = target and role = 'owner') then
    raise exception 'cannot_change_owner'; end if;
  update public.user_roles set role = new_role, updated_at = now() where user_id = target;
  if not found then raise exception 'not_found'; end if;
end $$;

create function public.admin_grant_permission(target uuid, perm text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'forbidden' using errcode = '42501'; end if;
  insert into public.user_permissions(user_id, permission_key, granted_by) values (target, perm, auth.uid())
  on conflict do nothing;
end $$;

create function public.admin_revoke_permission(target uuid, perm text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'forbidden' using errcode = '42501'; end if;
  delete from public.user_permissions where user_id = target and permission_key = perm;
end $$;

create function public.admin_list_users() returns table (
  id uuid, full_name text, email text, status public.account_status, role public.app_role,
  permissions text[], email_confirmed boolean, created_at timestamptz)
language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'forbidden' using errcode = '42501'; end if;
  return query
    select p.id, p.full_name, p.email, p.status, r.role,
           coalesce((select array_agg(up.permission_key order by up.permission_key)
                     from public.user_permissions up where up.user_id = p.id), '{}'::text[]),
           (u.email_confirmed_at is not null), p.created_at
    from public.profiles p
    join public.user_roles r on r.user_id = p.id
    join auth.users u on u.id = p.id
    order by (p.status = 'pending') desc, p.created_at desc;
end $$;

create function public.admin_stats() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'forbidden' using errcode = '42501'; end if;
  return jsonb_build_object(
    'users_total',     (select count(*) from public.profiles),
    'users_pending',   (select count(*) from public.profiles where status = 'pending'),
    'users_active',    (select count(*) from public.profiles where status = 'active'),
    'users_suspended', (select count(*) from public.profiles where status = 'suspended'),
    'courses',         (select count(*) from public.courses),
    'resources',       (select count(*) from public.resources),
    'storage_bytes',   (select coalesce(sum(file_size), 0) from public.resources));
end $$;

-- One-time owner bootstrap. NOT callable from the browser (no grants, see below).
-- Usage (SQL editor):  select public.bootstrap_owner('you@example.com');
-- Then remove it:      drop function public.bootstrap_owner(text);
create function public.bootstrap_owner(owner_email text) returns text
language plpgsql security definer set search_path = '' as $$
declare uid uuid;
begin
  if exists (select 1 from public.user_roles where role = 'owner') then raise exception 'owner_already_exists'; end if;
  select id into uid from auth.users where lower(email) = lower(owner_email) and email_confirmed_at is not null;
  if uid is null then raise exception 'user_not_found_or_email_unverified'; end if;
  update public.user_roles set role = 'owner', updated_at = now() where user_id = uid;
  update public.profiles   set status = 'active', status_changed_at = now() where id = uid;
  insert into public.audit_logs(actor_id, action, target_type, target_id) values (uid, 'bootstrap_owner', 'user_roles', uid::text);
  return 'ok';
end $$;

-- ---------- privileges: revoke everything, then grant the minimum ----------
alter default privileges in schema public revoke all on tables    from anon, authenticated;
alter default privileges in schema public revoke all on functions from public, anon, authenticated;
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;

grant usage on schema public to anon, authenticated;
grant select on public.site_settings to anon, authenticated;
grant select on public.profiles, public.user_roles, public.permissions, public.user_permissions,
                public.courses, public.categories, public.resources, public.course_access,
                public.resource_access, public.bookmarks, public.audit_logs to authenticated;
grant update (full_name) on public.profiles to authenticated;
grant update (site_title, site_subtitle, logo_url, registration_open, default_allow_download) on public.site_settings to authenticated;
grant insert, update, delete on public.courses, public.categories to authenticated;
grant update (course_id, category_id, title, description, tags, status, allow_download, restricted) on public.resources to authenticated;
grant insert, delete on public.course_access, public.resource_access to authenticated;
grant insert, delete on public.bookmarks to authenticated;

grant execute on function public.is_active_user(), public.is_owner(), public.has_permission(text),
  public.can_view_course(uuid), public.can_view_resource(uuid),
  public.admin_set_account_status(uuid, public.account_status), public.admin_set_role(uuid, public.app_role),
  public.admin_grant_permission(uuid, text), public.admin_revoke_permission(uuid, text),
  public.admin_list_users(), public.admin_stats() to authenticated;
-- bootstrap_owner: deliberately no grants (only the postgres role in the SQL editor can run it)

-- ---------- Row Level Security ----------
alter table public.profiles         enable row level security;
alter table public.user_roles       enable row level security;
alter table public.permissions      enable row level security;
alter table public.user_permissions enable row level security;
alter table public.courses          enable row level security;
alter table public.categories       enable row level security;
alter table public.resources        enable row level security;
alter table public.course_access    enable row level security;
alter table public.resource_access  enable row level security;
alter table public.bookmarks        enable row level security;
alter table public.audit_logs       enable row level security;
alter table public.site_settings    enable row level security;

create policy profiles_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_owner());
create policy profiles_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy roles_read      on public.user_roles for select to authenticated using (user_id = auth.uid() or public.is_owner());
create policy perms_read      on public.permissions for select to authenticated using (true);
create policy uperms_read     on public.user_permissions for select to authenticated using (user_id = auth.uid() or public.is_owner());

create policy courses_read   on public.courses for select to authenticated using (public.can_view_course(id));
create policy courses_insert on public.courses for insert to authenticated with check (public.has_permission('courses.manage'));
create policy courses_update on public.courses for update to authenticated using (public.has_permission('courses.manage')) with check (public.has_permission('courses.manage'));
create policy courses_delete on public.courses for delete to authenticated using (public.has_permission('courses.manage'));

create policy cat_read   on public.categories for select to authenticated using (public.can_view_course(course_id));
create policy cat_insert on public.categories for insert to authenticated with check (public.has_permission('categories.manage'));
create policy cat_update on public.categories for update to authenticated using (public.has_permission('categories.manage')) with check (public.has_permission('categories.manage'));
create policy cat_delete on public.categories for delete to authenticated using (public.has_permission('categories.manage'));

create policy res_read   on public.resources for select to authenticated using (public.can_view_resource(id));
create policy res_update on public.resources for update to authenticated using (public.has_permission('resources.edit')) with check (public.has_permission('resources.edit'));
-- no INSERT / DELETE policy on resources: only the Edge Function (service role) creates or deletes them

create policy cacc_read   on public.course_access   for select to authenticated using (user_id = auth.uid() or public.is_owner());
create policy cacc_insert on public.course_access   for insert to authenticated with check (public.is_owner());
create policy cacc_delete on public.course_access   for delete to authenticated using (public.is_owner());
create policy racc_read   on public.resource_access for select to authenticated using (user_id = auth.uid() or public.is_owner());
create policy racc_insert on public.resource_access for insert to authenticated with check (public.is_owner());
create policy racc_delete on public.resource_access for delete to authenticated using (public.is_owner());

create policy bm_read   on public.bookmarks for select to authenticated using (user_id = auth.uid());
create policy bm_insert on public.bookmarks for insert to authenticated with check (user_id = auth.uid() and public.can_view_resource(resource_id));
create policy bm_delete on public.bookmarks for delete to authenticated using (user_id = auth.uid());

create policy audit_read on public.audit_logs for select to authenticated using (public.is_owner());

create policy settings_read   on public.site_settings for select to anon, authenticated using (true);
create policy settings_update on public.site_settings for update to authenticated using (public.is_owner()) with check (public.is_owner());

-- ---------- Storage ----------
-- Private bucket for all study material (50 MB = Supabase free-plan ceiling; raise on paid plans).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('library', 'library', false, 52428800, array[
    'text/html','application/pdf','audio/mpeg','audio/mp4','audio/x-m4a','audio/wav','audio/x-wav','audio/aac',
    'image/png','image/jpeg','image/webp','image/gif',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- Public bucket ONLY for non-sensitive branding (logo, course icons). No SVG (script risk).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('branding', 'branding', true, 2097152, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- library: read only what can_view_resource allows; upload only into the caller's own pending/ folder.
create policy lib_read on storage.objects for select to authenticated
  using (bucket_id = 'library' and exists (
    select 1 from public.resources r where r.file_path = storage.objects.name and public.can_view_resource(r.id)));
create policy lib_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'library'
    and (public.has_permission('resources.upload') or public.has_permission('resources.edit'))
    and (storage.foldername(name))[1] = 'pending' and (storage.foldername(name))[2] = auth.uid()::text);
-- no UPDATE / DELETE policies on library: the Edge Function moves/removes objects with the service role.

create policy branding_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'branding' and (public.is_owner() or public.has_permission('courses.manage')));
create policy branding_update on storage.objects for update to authenticated
  using (bucket_id = 'branding' and (public.is_owner() or public.has_permission('courses.manage')));
create policy branding_delete on storage.objects for delete to authenticated
  using (bucket_id = 'branding' and (public.is_owner() or public.has_permission('courses.manage')));
