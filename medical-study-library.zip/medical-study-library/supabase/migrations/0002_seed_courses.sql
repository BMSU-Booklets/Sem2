-- Editable sample courses (no lecture content). Rename or delete them from the admin dashboard.
insert into public.courses (title, description, icon, sort_order) values
  ('کورس غدد',         'مقدمات، فارماکولوژی و پاتولوژی غدد', '🦋', 1),
  ('کورس گوارش',       'مقدمات، پاتولوژی، فارماکولوژی گوارش', '🫃', 2),
  ('کورس پاتولوژی',    'مباحث عمومی پاتولوژی', '🔬', 3),
  ('کورس فیزیولوژی',   'مباحث عمومی فیزیولوژی', '🫀', 4),
  ('کورس فارماکولوژی', 'مباحث عمومی فارماکولوژی', '💊', 5);

insert into public.categories (course_id, title, sort_order)
select c.id, t.title, t.ord from public.courses c
cross join (values ('مقدمات غدد',1),('فیزیولوژی',2),('فارماکولوژی',3),('پاتولوژی',4)) as t(title, ord)
where c.title = 'کورس غدد';
