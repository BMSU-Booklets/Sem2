// Edge Function: the ONLY path that creates, replaces or deletes library files/resources.
// Deploy: supabase functions deploy resource-admin   (JWT verification stays ON)
// Secrets available automatically: SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY.
// Optional secret: ALLOWED_ORIGIN (e.g. https://YOUR-USER.github.io) — defaults to "*" for local dev.
import { createClient } from 'npm:@supabase/supabase-js@2';
import { detectFileKind, MAX_FILE_BYTES, safeFileName } from '../_shared/fileKind.ts';

const ORIGIN = Deno.env.get('ALLOWED_ORIGIN') ?? '*';
const cors = {
  'Access-Control-Allow-Origin': ORIGIN,
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
};
const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

// Best-effort per-instance rate limit (20 calls / minute / user). Not a substitute for platform limits.
const hits = new Map<string, number[]>();
function limited(uid: string): boolean {
  const now = Date.now();
  const arr = (hits.get(uid) ?? []).filter((t) => now - t < 60_000);
  arr.push(now); hits.set(uid, arr);
  return arr.length > 20;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' });

  const url = Deno.env.get('SUPABASE_URL')!;
  const authHeader = req.headers.get('Authorization') ?? '';
  const asUser = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
  const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

  const { data: userData, error: userErr } = await asUser.auth.getUser();
  if (userErr || !userData.user) return json(401, { error: 'unauthenticated' });
  const uid = userData.user.id;
  if (limited(uid)) return json(429, { error: 'rate_limited' });

  // Permission checks run in the database under the caller's own JWT (suspended/unverified => false).
  const can = async (p: string) => (await asUser.rpc('has_permission', { p })).data === true;

  let body: any;
  try { body = await req.json(); } catch { return json(400, { error: 'bad_json' }); }

  try {
    if (body.action === 'register') return await register(body, uid, can, admin);
    if (body.action === 'delete') return await remove(body, uid, can, admin);
    return json(400, { error: 'unknown_action' });
  } catch (e) {
    console.error('resource-admin failure', (e as Error).message);
    return json(500, { error: 'server_error' });   // never leak internals
  }
});

async function register(b: any, uid: string, can: (p: string) => Promise<boolean>, admin: ReturnType<typeof createClient>) {
  const replaceId: string | null = b.replaceResourceId ?? null;
  if (replaceId !== null && !UUID.test(replaceId)) return json(400, { error: 'bad_id' });
  if (!(await can(replaceId ? 'resources.edit' : 'resources.upload'))) return json(403, { error: 'forbidden' });

  const pendingPath = String(b.pendingPath ?? '');
  if (!pendingPath.startsWith(`pending/${uid}/`) || pendingPath.includes('..')) return json(403, { error: 'bad_path' });
  const fileName = pendingPath.split('/').pop()!;

  const discard = () => admin.storage.from('library').remove([pendingPath]);

  // 1) real size from storage metadata
  const folder = `pending/${uid}`;
  const { data: listed } = await admin.storage.from('library').list(folder, { search: fileName, limit: 5 });
  const obj = listed?.find((o) => o.name === fileName);
  const size = Number(obj?.metadata?.size ?? 0);
  if (!obj || size <= 0) return json(400, { error: 'file_missing' });
  if (size > MAX_FILE_BYTES) { await discard(); return json(413, { error: 'file_too_large' }); }

  // 2) sniff the first bytes (ignores filename / declared MIME)
  const { data: signed } = await admin.storage.from('library').createSignedUrl(pendingPath, 60);
  const head = new Uint8Array(await (await fetch(signed!.signedUrl, { headers: { Range: 'bytes=0-8191' } })).arrayBuffer());
  const kind = detectFileKind(head, fileName);
  if (!kind) { await discard(); return json(415, { error: 'unsupported_or_mismatched_type' }); }

  // 3) metadata (validated again here; DB CHECK constraints are the last line of defence)
  const title = String(b.title ?? '').trim().slice(0, 200);
  if (!replaceId && !title) { await discard(); return json(400, { error: 'title_required' }); }
  const canPublish = await can('resources.publish');
  const wantPublished = b.status === 'published' && canPublish;
  const display = fileName.replace(/^[0-9a-f-]{36}-/, '');

  if (replaceId) {
    const { data: old } = await admin.from('resources').select('id, file_path, version').eq('id', replaceId).single();
    if (!old) { await discard(); return json(404, { error: 'not_found' }); }
    const finalPath = `resources/${replaceId}/${old.version + 1}-${crypto.randomUUID()}.${kind.ext}`;
    const mv = await admin.storage.from('library').move(pendingPath, finalPath);
    if (mv.error) { await discard(); return json(500, { error: 'move_failed' }); }
    const { error } = await admin.from('resources').update({
      file_path: finalPath, file_name: display, file_size: size, mime_type: kind.mime, type: kind.type,
      version: old.version + 1, uploaded_by: uid }).eq('id', replaceId);
    if (error) { await admin.storage.from('library').remove([finalPath]); return json(500, { error: 'db_failed' }); }
    await admin.storage.from('library').remove([old.file_path]);           // only the replaced file
    await admin.from('audit_logs').insert({ actor_id: uid, action: 'replace_file', target_type: 'resources', target_id: replaceId, details: { title } });
    return json(200, { id: replaceId });
  }

  const id = crypto.randomUUID();
  const finalPath = `resources/${id}/1-${crypto.randomUUID()}.${kind.ext}`;
  const mv = await admin.storage.from('library').move(pendingPath, finalPath);
  if (mv.error) { await discard(); return json(500, { error: 'move_failed' }); }
  const { error } = await admin.from('resources').insert({
    id, course_id: b.courseId, category_id: b.categoryId ?? null, title,
    description: String(b.description ?? '').slice(0, 2000),
    type: kind.type, tags: (Array.isArray(b.tags) ? b.tags : []).map((t: unknown) => String(t).slice(0, 40)).slice(0, 20),
    file_path: finalPath, file_name: safeFileName(display), file_size: size, mime_type: kind.mime,
    status: wantPublished ? 'published' : 'draft', allow_download: b.allowDownload === true,
    restricted: b.restricted === true, uploaded_by: uid });
  if (error) { await admin.storage.from('library').remove([finalPath]); return json(400, { error: 'invalid_metadata' }); }
  await admin.from('audit_logs').insert({ actor_id: uid, action: 'upload', target_type: 'resources', target_id: id, details: { title, type: kind.type, size } });
  return json(200, { id, status: wantPublished ? 'published' : 'draft' });
}

async function remove(b: any, uid: string, can: (p: string) => Promise<boolean>, admin: ReturnType<typeof createClient>) {
  if (!(await can('resources.delete'))) return json(403, { error: 'forbidden' });
  if (!UUID.test(String(b.resourceId))) return json(400, { error: 'bad_id' });
  const { data: row } = await admin.from('resources').select('id, file_path, title').eq('id', b.resourceId).single();
  if (!row) return json(404, { error: 'not_found' });
  // Remove exactly this row's object first; only then delete the row (no orphaned files, no collateral deletes).
  const rm = await admin.storage.from('library').remove([row.file_path]);
  if (rm.error) return json(500, { error: 'storage_delete_failed' });
  const { error } = await admin.from('resources').delete().eq('id', row.id);
  if (error) return json(500, { error: 'db_delete_failed' });
  await admin.from('audit_logs').insert({ actor_id: uid, action: 'delete_resource', target_type: 'resources', target_id: row.id, details: { title: row.title } });
  return json(200, { ok: true });
}
