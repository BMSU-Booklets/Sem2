// Pure TypeScript (no Deno/Node APIs) so it runs in the Edge Function, in the browser and in tests.
// The server never trusts the filename or the browser-supplied MIME type: it sniffs the first bytes.
export type ResourceType = 'html' | 'pdf' | 'audio' | 'image' | 'document';

export interface Detected { type: ResourceType; mime: string; ext: string }

export const MAX_FILE_BYTES = 50 * 1024 * 1024;

const EXT_TO_TYPE: Record<string, ResourceType> = {
  html: 'html', htm: 'html', pdf: 'pdf',
  mp3: 'audio', m4a: 'audio', wav: 'audio', aac: 'audio',
  png: 'image', jpg: 'image', jpeg: 'image', webp: 'image', gif: 'image',
  docx: 'document', pptx: 'document', xlsx: 'document',
};
const OOXML_MIME: Record<string, string> = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
};

export const ALLOWED_EXTENSIONS = Object.keys(EXT_TO_TYPE);

export function extensionOf(name: string): string {
  const m = /\.([A-Za-z0-9]{1,5})$/.exec(name.trim());
  return m ? m[1].toLowerCase() : '';
}

const ascii = (b: Uint8Array, from: number, s: string) => {
  for (let i = 0; i < s.length; i++) if (b[from + i] !== s.charCodeAt(i)) return false;
  return true;
};

/** Returns the detected kind, or null if the bytes do not match any allowed format
 *  or do not match the claimed extension. */
export function detectFileKind(head: Uint8Array, fileName: string): Detected | null {
  const ext = extensionOf(fileName);
  const claimed = EXT_TO_TYPE[ext];
  if (!claimed) return null;
  let found: Detected | null = null;

  if (ascii(head, 0, '%PDF-')) found = { type: 'pdf', mime: 'application/pdf', ext: 'pdf' };
  else if (head[0] === 0x89 && ascii(head, 1, 'PNG')) found = { type: 'image', mime: 'image/png', ext: 'png' };
  else if (head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff) found = { type: 'image', mime: 'image/jpeg', ext: ext === 'jpeg' ? 'jpeg' : 'jpg' };
  else if (ascii(head, 0, 'GIF8')) found = { type: 'image', mime: 'image/gif', ext: 'gif' };
  else if (ascii(head, 0, 'RIFF') && ascii(head, 8, 'WEBP')) found = { type: 'image', mime: 'image/webp', ext: 'webp' };
  else if (ascii(head, 0, 'RIFF') && ascii(head, 8, 'WAVE')) found = { type: 'audio', mime: 'audio/wav', ext: 'wav' };
  else if (ascii(head, 0, 'ID3') || (head[0] === 0xff && (head[1] & 0xe0) === 0xe0 && ext === 'mp3'))
    found = { type: 'audio', mime: 'audio/mpeg', ext: 'mp3' };
  else if (ascii(head, 4, 'ftyp') && ext === 'm4a') found = { type: 'audio', mime: 'audio/mp4', ext: 'm4a' };
  else if (head[0] === 0xff && (head[1] & 0xf6) === 0xf0 && ext === 'aac') found = { type: 'audio', mime: 'audio/aac', ext: 'aac' };
  else if (head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x03 && head[3] === 0x04 && OOXML_MIME[ext])
    found = { type: 'document', mime: OOXML_MIME[ext], ext };
  else if ((ext === 'html' || ext === 'htm') && looksLikeHtml(head))
    found = { type: 'html', mime: 'text/html', ext: 'html' };

  if (!found || found.type !== claimed) return null;
  // jpg/jpeg and htm/html are interchangeable extensions of the same format
  return found;
}

function looksLikeHtml(head: Uint8Array): boolean {
  const n = Math.min(head.length, 4096);
  for (let i = 0; i < n; i++) if (head[i] === 0) return false;       // binary => not HTML
  let start = 0;
  if (head[0] === 0xef && head[1] === 0xbb && head[2] === 0xbf) start = 3; // UTF-8 BOM
  const text = new TextDecoder('utf-8', { fatal: false }).decode(head.subarray(start, n));
  return /<\s*(!doctype\s+html|html|head|body|div|p|h[1-6]|table|section|article|script|style|meta|title)\b/i.test(text);
}

export function safeFileName(name: string): string {
  const base = name.replace(/[\\/\u0000-\u001f]/g, '_').replace(/\s+/g, '_');
  return base.slice(-120);
}
