import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildSandboxDoc, SANDBOX_ATTR, SANDBOX_CSP } from '../src/lib/htmlSandbox.ts';

test('sandbox attribute never grants same-origin or top navigation', () => {
  assert.ok(!SANDBOX_ATTR.includes('allow-same-origin'));
  assert.ok(!SANDBOX_ATTR.includes('allow-top-navigation'));
  assert.ok(SANDBOX_ATTR.includes('allow-scripts'));
});
test('CSP blocks network, frames and forms', () => {
  for (const d of ["default-src 'none'", "connect-src 'none'", "frame-src 'none'", "form-action 'none'", "base-uri 'none'"]) assert.ok(SANDBOX_CSP.includes(d), d);
});
test('CSP meta is injected right after <head>', () => {
  const out = buildSandboxDoc('<!doctype html><html><head><title>t</title></head><body>x</body></html>');
  assert.ok(out.indexOf('Content-Security-Policy') < out.indexOf('<title>'));
});
test('author-supplied CSP and <base> are removed', () => {
  const out = buildSandboxDoc('<html><head><base href="https://evil.test/"><meta http-equiv="Content-Security-Policy" content="default-src *"></head><body></body></html>');
  assert.ok(!out.includes('evil.test'));
  assert.ok(!out.includes('default-src *'));
});
test('fragments without <head> are wrapped with the CSP', () => {
  assert.ok(buildSandboxDoc('<p>hello</p>').includes('Content-Security-Policy'));
  assert.ok(buildSandboxDoc('<html><body>x</body></html>').includes('Content-Security-Policy'));
});
