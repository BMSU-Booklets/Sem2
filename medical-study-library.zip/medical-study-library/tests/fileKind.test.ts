import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detectFileKind, extensionOf, safeFileName } from '../supabase/functions/_shared/fileKind.ts';

const b = (...x: (number | string)[]) => Uint8Array.from(x.flatMap((v) => (typeof v === 'string' ? [...v].map((c) => c.charCodeAt(0)) : [v])));
const pad = (u: Uint8Array) => { const o = new Uint8Array(64); o.set(u); return o; };

test('PDF magic bytes are accepted for .pdf', () => assert.equal(detectFileKind(pad(b('%PDF-1.7')), 'a.pdf')?.type, 'pdf'));
test('PDF bytes with .html extension are rejected (extension/content mismatch)', () => assert.equal(detectFileKind(pad(b('%PDF-1.7')), 'a.html'), null));
test('HTML text is accepted as html', () => assert.equal(detectFileKind(b('<!DOCTYPE html><html><body>سلام</body></html>'), 'note.html')?.type, 'html'));
test('.html with binary content is rejected', () => assert.equal(detectFileKind(Uint8Array.from([0x4d, 0x5a, 0, 0, 0x90]), 'x.html'), null));
test('.html that is plain prose without tags is rejected', () => assert.equal(detectFileKind(b('just some words, no markup'), 'x.html'), null));
test('Windows executable renamed to .pdf is rejected', () => assert.equal(detectFileKind(pad(b('MZ')), 'evil.pdf'), null));
test('PNG / JPEG / GIF / WebP are detected', () => {
  assert.equal(detectFileKind(pad(b(0x89, 'PNG')), 'a.png')?.mime, 'image/png');
  assert.equal(detectFileKind(pad(b(0xff, 0xd8, 0xff, 0xe0)), 'a.jpg')?.mime, 'image/jpeg');
  assert.equal(detectFileKind(pad(b('GIF89a')), 'a.gif')?.mime, 'image/gif');
  assert.equal(detectFileKind(pad(b('RIFF', 0, 0, 0, 0, 'WEBP')), 'a.webp')?.mime, 'image/webp');
});
test('audio: mp3 (ID3), wav, m4a', () => {
  assert.equal(detectFileKind(pad(b('ID3', 4)), 'l.mp3')?.type, 'audio');
  assert.equal(detectFileKind(pad(b('RIFF', 0, 0, 0, 0, 'WAVEfmt ')), 'l.wav')?.mime, 'audio/wav');
  assert.equal(detectFileKind(pad(b(0, 0, 0, 0x20, 'ftypM4A ')), 'l.m4a')?.mime, 'audio/mp4');
});
test('OOXML (zip) accepted only with docx/pptx/xlsx extension', () => {
  assert.equal(detectFileKind(pad(b(0x50, 0x4b, 3, 4)), 'a.pptx')?.type, 'document');
  assert.equal(detectFileKind(pad(b(0x50, 0x4b, 3, 4)), 'a.zip'), null);
});
test('SVG and unknown extensions are rejected', () => {
  assert.equal(detectFileKind(b('<svg xmlns="http://www.w3.org/2000/svg"></svg>'), 'a.svg'), null);
  assert.equal(detectFileKind(b('<html></html>'), 'a.exe'), null);
});
test('extensionOf / safeFileName', () => {
  assert.equal(extensionOf('Lecture.FINAL.MP3'), 'mp3');
  assert.equal(extensionOf('noext'), '');
  assert.equal(safeFileName('../../etc/passwd'), '.._.._etc_passwd');
});
