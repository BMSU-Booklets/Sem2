import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatBytes, friendlyError, toFaDigits, validateLogin, validateRegister } from '../src/lib/fa.ts';

test('register: valid input has no errors', () =>
  assert.deepEqual(validateRegister({ fullName: 'علی رضایی', email: 'a@b.com', password: 'abc12345', confirm: 'abc12345' }), {}));
test('register: Persian error messages for every bad field', () => {
  const e = validateRegister({ fullName: 'ع', email: 'bad', password: 'short', confirm: 'x' });
  assert.ok(e.fullName && e.email && e.password && e.confirm);
  assert.match(e.email!, /ایمیل/);
});
test('register: password needs letters and digits', () => assert.ok(validateRegister({ fullName: 'علی رضایی', email: 'a@b.com', password: 'abcdefgh', confirm: 'abcdefgh' }).password));
test('login validation', () => { assert.ok(validateLogin({ email: '', password: '' }).email); assert.deepEqual(validateLogin({ email: 'a@b.co', password: 'x' }), {}); });
test('friendlyError maps known errors and hides unknown details', () => {
  assert.match(friendlyError(new Error('Invalid login credentials')), /ایمیل یا گذرواژه/);
  assert.match(friendlyError(new Error('new row violates row-level security policy')), /اجازه/);
  assert.equal(friendlyError(new Error('SELECT * FROM secret_table failed at 10.0.0.5')), 'خطایی رخ داد. دوباره تلاش کنید.');
});
test('Persian digits and byte formatting', () => { assert.equal(toFaDigits(2026), '۲۰۲۶'); assert.match(formatBytes(5 * 1024 * 1024), /مگابایت/); });
